import sys,termios,runpy,json
from pathlib import Path
from display_math import normalize
fd=sys.stdin.fileno();old=termios.tcgetattr(fd);new=list(old);new[3]&=~termios.ECHO
termios.tcsetattr(fd,termios.TCSANOW,new);print('AUTH_INPUT_READY',flush=True)
try:key=sys.stdin.readline().strip()
finally:termios.tcsetattr(fd,termios.TCSANOW,old)
m=runpy.run_path(str(Path(__file__).with_name('Lain-Zip-Apertus-API-Test.py')),run_name='zip_api_runtime')
work=Path(__file__).parent/'results';h=m['setup'](work);c=m['PLAN']['cases'][0]
out=work/'zip-apertus-display-recovery-70b';out.mkdir(exist_ok=True)
original=[h['read'](p) for p in (work/'zip-apertus-power-70b'/'raw').glob('*.json')][0]
retraction=[h['read'](p) for p in (work/'zip-apertus-natural-70b'/'raw').glob('*.json')][0]
parent=h['check_seal'](h['read'](work/'zip-apertus-natural-70b'/'result.json'))
h['put_once'](out/'protocol.json',h['sealed']({'model':'swiss-ai/Apertus-v1.5-70B','originalPowerRecordId':original['recordId'],'originalPowerRecordHash':original['hash'],'parentRetractionRecordId':retraction['recordId'],'displayNormalization':'superscript digit sequence after name/number/closing-parenthesis -> ** plus the same digits','rawOutputsUntouched':True,'mathematicalContentChanged':False,'exploratoryAfterParserFailure':True,'oneFollowupOnly':True,'combinedMaxCalls':72}))
def display_record(r):
    return h['sealed']({'recordId':r['recordId']+'-display-normalized','caseCardId':r['caseCardId'],'sourceRecordId':r['recordId'],'sourceRecordHash':r['hash'],'originalRaw':r['studentOutput']['raw'],'presentationOnly':True,'studentOutput':{'raw':normalize(r['studentOutput']['raw']),'tokenCapReached':r['studentOutput']['tokenCapReached']}})
try:
    if parent['action']!='RETRACT':raise RuntimeError('Actual model withdrawal required')
    p=display_record(original);h['put_once'](out/'normalized-proposal.json',p)
    audit=h['proposal_audit'](c,p);h['put_once'](out/'normalized-proposal-audit.json',h['sealed'](audit))
    before=h['initial'](c['card']);d={k:v for k,v in retraction.items() if k!='hash'};d['action']=parent['action']
    after=h['apply_action'](before,h['sealed'](d));after=h['attach_proposal'](after,p,audit)
    h['put_once'](out/'old-note.json',before);h['put_once'](out/'new-note.json',after)
    after=h['check_seal'](h['read'](out/'new-note.json'));follow=None;strict=False
    if audit['accepted']:
        cfg={'key':key,'url':'https://api.inference.cscs.ch/v1','model':'swiss-ai/Apertus-v1.5-70B','token_field':'max_tokens','budget':1024,'extra':{'temperature':0}}
        api=m['API'](cfg,out,h)
        if len(list(work.glob('*/attempts/*.json')))>=72:raise RuntimeError('Combined 72-attempt cap reached')
        task,prompt=h['followup'](after,'q',False,1)
        prompt[0]['content']='Apply the retrieved saved ZIP when valid. Represent repeated identical factors using powers. Return ONE expression using * and ** without prose or an equality chain.'
        r=api.ask('persisted_self_written_rule_follow_q',c,prompt);normalized=display_record(r)
        h['put_once'](out/'normalized-followup.json',normalized)
        a=h['math_audit'](task,normalized);strict=bool(a['correctChangedExpression'] and a['fullAudit']['correctSimplifiedAnswer'])
        follow={'recordId':r['recordId'],'originalRaw':r['studentOutput']['raw'],'normalizedRaw':normalized['studentOutput']['raw'],'audit':a,'strictCollectedAnswerCorrect':strict}
    row=h['sealed']({'complete':True,'model':'swiss-ai/Apertus-v1.5-70B','exploratory':True,'inheritedNote':True,'actualParentAction':parent['action'],'originalProposalRaw':original['studentOutput']['raw'],'presentationNormalizedProposal':p['studentOutput']['raw'],'replacementAccepted':audit['accepted'],'studentReplacement':audit['studentFinal'],'followup':follow,'candidateOneFollowupClosedLoop':audit['accepted'] and strict,'predeclaredTwoFollowupCriterionMet':False,'ownUnnoticedErrorRepairProven':False,'causalMemoryBenefitOverMatchedNoNoteControlProven':False,'humanReflectionReviewRequired':True})
    h['put_once'](out/'result.json',row);print(json.dumps({k:v for k,v in row.items() if k not in ('hash','followup')},ensure_ascii=False),flush=True)
except Exception as e:print('RUN_STOPPED '+(str(e) if type(e) is RuntimeError else type(e).__name__),flush=True)
finally:key=None
