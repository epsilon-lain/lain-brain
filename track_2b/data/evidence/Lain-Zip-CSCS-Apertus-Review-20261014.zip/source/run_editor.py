import sys,termios,runpy,json
from pathlib import Path
fd=sys.stdin.fileno();old=termios.tcgetattr(fd);new=list(old);new[3]&=~termios.ECHO
termios.tcsetattr(fd,termios.TCSANOW,new);print('AUTH_INPUT_READY',flush=True)
try:key=sys.stdin.readline().strip()
finally:termios.tcsetattr(fd,termios.TCSANOW,old)
m=runpy.run_path(str(Path(__file__).with_name('Lain-Zip-Apertus-API-Test.py')),run_name='zip_api_runtime')
work=Path(__file__).parent/'results';h=m['setup'](work);c=m['PLAN']['cases'][0]
try:
 for size in ('70B','8B'):
    prior=work/('zip-apertus-natural-'+size.lower());result=h['check_seal'](h['read'](prior/'result.json'))
    if result['action']!='RETRACT':continue
    original=[h['read'](p) for p in (prior/'raw').glob('*.json')][0]
    cfg={'key':key,'url':'https://api.inference.cscs.ch/v1','model':result['model'],'token_field':'max_tokens','budget':1024,'extra':{'temperature':0}}
    out=work/('zip-apertus-editor-'+size.lower());out.mkdir(exist_ok=True)
    h['put_once'](out/'protocol.json',h['sealed']({'model':cfg['model'],'parentResultHash':result['hash'],'parentRevisionRecordId':original['recordId'],'actualStudentRetractionRequired':True,'writerPromptOmitsOldWrongFormulaAndFactorLabels':True,'oneFollowupOnly':True,'exploratoryAfterNullReplacement':True,'maxCallsPerModel':2,'combinedMaxCalls':72,'teacherReplacementSupplied':False}))
    api=m['API'](cfg,out,h);orig=api.ask
    def ask(*a,**kw):
        if len(list(work.glob('*/attempts/*.json')))>=72:raise RuntimeError('Combined 72-attempt cap reached')
        return orig(*a,**kw)
    api.ask=ask
    before=h['initial'](c['card']);decision={k:v for k,v in original.items() if k!='hash'};decision['action']=result['action']
    after=h['apply_action'](before,h['sealed'](decision))
    messages=[{'role':'system','content':'Write ONE collected algebraic expression. Use * and **. Do not write an equality chain. If unsure write SKIP.'},{'role':'user','content':'You withdrew a previous universal rule. Create a replacement ZIP by collecting only the ORIGINAL product: 435 * v * v. v is an arbitrary real number. Your expression, not a teacher answer, will be saved as the new rule.'}]
    proposal=api.ask('independent_editor',c,messages);audit=h['proposal_audit'](c,proposal)
    after=h['attach_proposal'](after,proposal,audit);h['put_once'](out/'replacement-audit.json',h['sealed'](audit))
    h['put_once'](out/'old-note.json',before);h['put_once'](out/'new-note.json',after)
    after=h['check_seal'](h['read'](out/'new-note.json'));follow=None;strict=False
    if audit['accepted']:
        task,prompt=h['followup'](after,'q',False,1);answer=api.ask('saved_note_follow_q',c,prompt)
        a=h['math_audit'](task,answer);strict=bool(a['correctChangedExpression'] and a['fullAudit']['correctSimplifiedAnswer'])
        follow={'recordId':answer['recordId'],'raw':answer['studentOutput']['raw'],'audit':a,'strictCollectedAnswerCorrect':strict}
    row=h['sealed']({'complete':True,'model':cfg['model'],'exploratory':True,'inheritedNote':True,'actualParentAction':result['action'],'proposalRaw':proposal['studentOutput']['raw'],'replacementAccepted':audit['accepted'],'studentReplacement':audit['studentFinal'],'followup':follow,'candidateOneFollowupClosedLoop':bool(audit['accepted'] and strict),'predeclaredTwoFollowupCriterionMet':False,'ownUnnoticedErrorRepairProven':False,'parentReflectionSemanticsRequireReview':True})
    h['put_once'](out/'result.json',row);print(json.dumps({k:v for k,v in row.items() if k not in ('hash','followup')},ensure_ascii=False),flush=True)
except Exception as e:
 print('RUN_STOPPED '+(str(e) if type(e) is RuntimeError else type(e).__name__),flush=True)
finally:key=None
