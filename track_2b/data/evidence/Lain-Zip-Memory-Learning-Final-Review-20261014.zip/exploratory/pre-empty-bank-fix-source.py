"""Exploratory feedback-conditioned note writing; no parameter updates.

Frozen before the recipe call. Retains the primary v27 scores unchanged.
Ten additional requests; combined attempted-POST cap remains 112.
"""
import hashlib,json,runpy,sys,termios
from pathlib import Path
ROOT=Path(__file__).parent
L=runpy.run_path(str(ROOT/'learn_memory_policy.py'),run_name='feedback_note')
H=L['H'];M=L['M'];PRIMARY=L['WORK']/'zip-policy-5411d33ddbc5'
OUT=L['WORK']/'feedback-note-pilot'
PLAN={'protocol':'lain-feedback-note-exploratory-v1','TRAINFeedbackCaseId':'policy-case-0',
 'TESTCaseIds':['policy-case-6','policy-case-7','policy-case-9'],
 'noteRecipeLearnedFromTRAINFeedbackOnly':True,'noteFormatChosenByLLM':True,
 'humanPromptEncouragesEvidencePreservation':True,'newModelWeightUpdates':0,
 'newCalls':10,'combinedAttemptedPOSTCap':112,'futureInputs':[2,4],
 'sameFuturePromptsAndScoringAsPrimary':True,'noGoldFormulaOrFutureAnswerSupplied':True,
 'primaryV27RewardsUnchanged':True,'exploratoryNotPreregisteredConfirmatory':True,
 'humanUnknownStrategyClaimed':False}
OUT.mkdir(exist_ok=True)
H['put_once'](OUT/'protocol.json',H['sealed'](PLAN))

def run(key):
 H['check_seal'](H['read'](PRIMARY/'result.json')) # Primary completes first.
 cfg={'key':key,'url':'https://api.inference.cscs.ch/v1','model':L['PLAN']['model'],
      'token_field':'max_tokens','budget':512,'extra':{'temperature':0}}
 api=M['API'](cfg,OUT,H)
 original_ask=api.ask
 def ask(phase,c,prompt):
  public={k:v for k,v in cfg.items() if k!='key'}
  body={'model':cfg['model'],'messages':prompt,cfg['token_field']:cfg['budget'],**cfg['extra']}
  ident=H['digest']({'config':public,'phase':phase,'case':c['id'],'body':body})
  if not (OUT/'raw'/(ident+'.json')).exists():
   used=sum(len(list((p/'attempts').glob('*.json'))) for p in (PRIMARY,OUT))
   if used>=112:raise RuntimeError('Combined frozen attempted-POST cap 112 reached')
  return original_ask(phase,c,prompt)
 train=H['check_seal'](H['read'](PRIMARY/'cases'/'policy-case-0'/'outcomes.json'))
 c=L['PLAN']['cases'][0]
 prompt=[{'role':'system','content':'You are improving your own reusable notes after actual downstream feedback. Suggest a short general note-writing procedure. You may choose the representation; keep its factual basis auditable. Do not refer to hidden answers or future test cases.'},
 {'role':'user','content':'Public task family: an opaque affine function of integer x. Your TRAIN observations were '+json.dumps(c['newObservations'])+'. Your own written note was '+train['newRaw']+'. Using this note, later answers scored '+str(sum(a['score']['correct'] for a in train['operations']['OVERWRITE']['answers']))+'/2 correct. No gold formula or answer is provided. Propose a general way to write useful memory from observations, avoid inventing coefficients, and distinguish insufficient evidence. You may preserve observations in the note and include a derivation if helpful. Return only the general procedure.'}]
 recipe=ask('TRAIN_note_procedure',c,prompt)
 primaryraw={r['recordId']:r for p in (PRIMARY/'raw').glob('*.json') for r in [H['check_seal'](H['read'](p))]}
 rows=[]
 for cid in PLAN['TESTCaseIds']:
  c=next(c for c in L['PLAN']['cases'] if c['id']==cid)
  old=H['check_seal'](H['read'](PRIMARY/'cases'/cid/'outcomes.json'))
  prompt=[{'role':'system','content':'Write a reusable working note according to your own TRAIN-derived procedure. Keep facts and uncertainty clear; any formula must come from these observations. No target formula is supplied. You may choose the note format.'},
   {'role':'user','content':'Your note-writing procedure:\n'+recipe['studentOutput']['raw']+'\nCurrent observations of opaque affine function '+c['functionName']+':\n'+'\n'.join(str(x)+' -> '+str(y) for x,y in c['newObservations'])+'\nWrite only the reusable note.'}]
  note=ask('TEST_flexible_note',c,prompt)
  state=H['sealed']({'caseId':cid,'activeNotes':[note['studentOutput']['raw']],
       'recipeRecordId':recipe['recordId'],'noteRecordId':note['recordId'],
       'hostAuthoredFormula':False,'actorWeightsUpdated':False})
  H['put_once'](OUT/'memory'/(cid+'.json'),state)
  state=H['check_seal'](H['read'](OUT/'memory'/(cid+'.json')));answers=[]
  for point,base in zip(c['futureInputs'],old['operations']['OVERWRITE']['answers']):
   prompt=[dict(m) for m in primaryraw[base['recordId']]['request']['messages']]
   old_part=c['functionName']+'(x) = '+old['newRaw']
   assert prompt[1]['content'].count(old_part)==1
   prompt[1]['content']=prompt[1]['content'].replace(old_part,c['functionName']+'(x) = '+state['activeNotes'][0])
   rr=ask('TEST_flexible_future_'+str(point),c,prompt)
   expected=c['currentHiddenCoefficients'][0]*point+c['currentHiddenCoefficients'][1]
   score=L['score_value'](rr['studentOutput']['raw'],expected,rr['studentOutput']['tokenCapReached'])
   answers.append({'input':point,'recordId':rr['recordId'],'raw':rr['studentOutput']['raw'],'score':score,
       'expectedValueAuditOnly':expected,'primaryFormulaBaseline':base})
  rows.append({'caseId':cid,'newNoteRaw':note['studentOutput']['raw'],'memoryHash':state['hash'],'answers':answers})
 result=H['sealed']({'complete':True,'exploratory':True,'recipeRaw':recipe['studentOutput']['raw'],'rows':rows,
  'flexibleNoteCorrect':sum(a['score']['correct'] for r in rows for a in r['answers']),
  'primaryFormulaNoteCorrect':sum(a['primaryFormulaBaseline']['score']['correct'] for r in rows for a in r['answers']),
  'denominator':6,'actualAdditionalAttempts':len(list((OUT/'attempts').glob('*.json'))),
  'noteWritingWeightUpdates':0,'humanUnknownMethodDiscoveryClaimed':False,
  'samePromptExceptActiveNote':True,'primaryResultsUnchanged':True})
 H['put_once'](OUT/'result.json',result)
 print(json.dumps(result,ensure_ascii=False,indent=2),flush=True)

if __name__=='__main__':
 if '--freeze' in sys.argv:print('Exploratory protocol frozen: TRAIN-only feedback, 3 TEST contexts, 10 additional calls, combined cap112.')
 else:
  fd=sys.stdin.fileno();old=termios.tcgetattr(fd);new=list(old);new[3]&=~termios.ECHO
  termios.tcsetattr(fd,termios.TCSANOW,new);print('AUTH_INPUT_READY',flush=True)
  try:key=sys.stdin.readline().strip()
  finally:termios.tcsetattr(fd,termios.TCSANOW,old)
  try:run(key)
  except Exception as e:print('RUN_STOPPED '+(str(e) if isinstance(e,RuntimeError) else type(e).__name__),flush=True);sys.exit(1)
  finally:key=None
