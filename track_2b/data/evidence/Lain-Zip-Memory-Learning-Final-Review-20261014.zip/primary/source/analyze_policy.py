"""Independent replay audit; no API requests or changes to frozen outcomes."""
import hashlib,json,re,runpy,zipfile
from pathlib import Path
import numpy as np

ROOT=Path(__file__).parent
L=runpy.run_path(str(ROOT/'learn_memory_policy.py'),run_name='audit_policy')
H=L['H'];P=L['PLAN'];A=L['ACTIONS'];OUT=L['WORK']/'zip-policy-5411d33ddbc5'
R=H['check_seal'](H['read'](OUT/'result.json'))
raw={r['recordId']:r for p in (OUT/'raw').glob('*.json') for r in [H['check_seal'](H['read'](p))]}
cases=[];lookup={c['id']:c for c in P['cases']}
for c in P['cases']:
 row=H['check_seal'](H['read'](OUT/'cases'/c['id']/'outcomes.json'))
 assert row['oldRaw']==raw[row['oldNoteRecordId']]['studentOutput']['raw']
 assert row['newRaw']==raw[row['newNoteRecordId']]['studentOutput']['raw']
 np.testing.assert_array_equal(row['featureVector'],L['features'](c,row['oldRaw'],row['newRaw']))
 for action in A:
  op=row['operations'][action]
  bank=H['check_seal'](H['read'](OUT/'cases'/c['id']/('memory-'+action+'.json')))
  assert bank['activeNotes']==L['memory'](row['oldRaw'],row['newRaw'],action)
  assert bank['hash']==op['memoryHash']
  for point,answer in zip(c['futureInputs'],op['answers']):
   rr=raw[answer['recordId']];expected=c['currentHiddenCoefficients'][0]*point+c['currentHiddenCoefficients'][1]
   assert rr['studentOutput']['raw']==answer['raw'] and expected==answer['expectedValueAuditOnly']
   assert L['score_value'](answer['raw'],expected,rr['studentOutput']['tokenCapReached'])==answer['score']
  reward=sum(a['score']['reward'] for a in op['answers'])/2
  cost=P['operationCosts'][action]+.001*sum(map(len,bank['activeNotes']))
  assert np.isclose(op['utility'],reward-cost)
 cases.append(row)

# Replay every actual parameter update from scratch, including RNG and Adam.
train=cases[:6];rng=np.random.default_rng(L['SEED']);w=np.zeros((4,8));m=w.copy();v=w.copy();b=np.zeros(6)
schedule=np.tile(np.arange(6),(L['STEPS']+5)//6)[:L['STEPS']]
for block in range(0,len(schedule),6):rng.shuffle(schedule[block:block+6])
for step,index in enumerate(schedule,1):
 rec=H['check_seal'](H['read'](OUT/'controller-commits'/('step-'+str(step).zfill(4)+'.json')))
 row=train[int(index)];x=np.asarray(row['featureVector']);p=L['probabilities'](w,x);u=float(rng.random());a=min(int(np.searchsorted(p.cumsum(),u)),3)
 reward=row['operations'][A[a]]['utility'];adv=reward-b[index]
 assert rec['TRAINCaseId']==row['caseId'] and rec['sourceOutcomeHash']==row['hash'] and rec['chosenOperation']==A[a]
 assert rec['samplingUniform']==u and rec['beforeWeightHash']==H['digest'](w.tolist())
 np.testing.assert_array_equal(rec['samplingProbabilities'],p)
 g=p.copy();g[a]-=1;gradient=adv*g[:,None]*x[None,:]
 m=.9*m+.1*gradient;v=.999*v+.001*gradient**2
 w-=L['LR']*(m/(1-.9**step))/(np.sqrt(v/(1-.999**step))+1e-8);b[index]=.85*b[index]+.15*reward
 np.testing.assert_array_equal(rec['weights'],w);np.testing.assert_array_equal(rec['adamFirstMoment'],m);np.testing.assert_array_equal(rec['adamSecondMoment'],v)
 assert rec['afterWeightHash']==H['digest'](w.tolist()) and rec['zeroRewardOptimizerSteps']==0
 assert not np.any(rec['zeroRewardWeights']) and not rec['APIModelWeightsUpdated']
final=H['check_seal'](H['read'](OUT/'final-controller.json'));np.testing.assert_array_equal(final['weights'],w)
for row in cases[6:]:
 decision=H['check_seal'](H['read'](OUT/'TEST-decisions'/(row['caseId']+'.json')))
 p=L['probabilities'](w,np.asarray(row['featureVector']))
 assert decision['action']==A[int(p.argmax())] and not decision['TESTRewardUsedForSelection']
 np.testing.assert_array_equal(decision['probabilities'],p)
 assert decision['weightHash']==final['weightHash']

# Secondary read-only content check: only a single explicit final integer or
# SKIP can be extracted from prose. It does not change any primary rewards.
def secondary(text,expected):
 text=text.strip()
 if re.fullmatch(r'[+-]?\d+',text):return 'correct' if int(text)==expected else 'wrong'
 last=text.splitlines()[-1].strip()
 if last.upper()=='SKIP':return 'skip'
 match=re.fullmatch(r'(?:Answer|Result|Final answer)\s*:\s*([+-]?\d+)',last,re.I)
 if match:return 'correct' if int(match.group(1))==expected else 'wrong'
 return 'unresolved'

counts={}
for action in (*A,'LEARNED'):
 stats={'correct':0,'wrongInteger':0,'skip':0,'format':0,'secondaryExplicitCorrect':0,'secondaryExplicitWrong':0}
 for row in cases[6:]:
  chosen=action if action!='LEARNED' else next(t['decision']['action'] for t in R['TESTRows'] if t['caseId']==row['caseId'])
  for ans in row['operations'][chosen]['answers']:
   score=ans['score'];stats['correct']+=int(score['correct']);stats['wrongInteger']+=int(score['kind']=='integer' and not score['correct'])
   stats['skip']+=int(score['kind']=='skip');stats['format']+=int(score['kind']=='format')
   sem=secondary(ans['raw'],ans['expectedValueAuditOnly']);stats['secondaryExplicitCorrect']+=int(sem=='correct');stats['secondaryExplicitWrong']+=int(sem=='wrong')
 counts[action]=stats
attempts=[H['read'](p) for p in (OUT/'attempts').glob('*.json')]
sealed=0
for p in OUT.rglob('*.json'):
 d=H['read'](p)
 if isinstance(d,dict) and 'hash' in d:H['check_seal'](d);sealed+=1
summary={'primaryResult':R,'heldoutAnswerBreakdown':counts,'controllerUpdatesIndependentlyReplayed':L['STEPS'],
 'allRawAnswerRewardAndMemoryLinksChecked':True,'sealedJSONChecked':sealed,
 'realCommittedResponses':len(raw),'attemptedPOSTs':len(attempts),'pendingUncertainAttempts':sum(a['status']=='pending' for a in attempts),
 'completionTokens':sum((r.get('usage') or {}).get('completion_tokens',0) for r in raw.values()),
 'modelIDs':sorted({r['responseModel'] for r in raw.values()}),
 'TRAINNoteFits':[{ 'caseId':row['caseId'],'oldFitsOldObservedPoints':L['fits'](row['oldRaw'],lookup[row['caseId']]['oldObservations']),
 'newFitsNewObservedPoints':L['fits'](row['newRaw'],lookup[row['caseId']]['newObservations']),
 'newIsSKIP':row['newRaw'].strip().upper()=='SKIP'} for row in train],
 'affineFitsComputedByHostRatherThanLearnedByActor':True,
 'zeroRewardControlIsNoUpdateReferenceNotIndependentAPIRollout':True,
 'heldoutSelectionUsesCachedRealOperationTrialsNotNewPolicyRollouts':True,
 'humanUnknownStrategyDiscoveryClaimed':False,'statisticalSignificanceClaimed':False}
H['atomic_json'](OUT/'analysis.json',H['sealed'](summary))
table='\n'.join('| '+a+' | '+str(counts[a]['correct'])+'/8 | '+str(counts[a]['wrongInteger'])+' | '+str(counts[a]['skip'])+' | '+str(counts[a]['format'])+' |' for a in (*A,'LEARNED'))
best=max(R['constantOperationMeanUtility'],key=R['constantOperationMeanUtility'].get)
report=f'''# Outcome-trained memory-operation pilot (v27)

## Verified result

Model: {P['model']}. Six TRAIN environments, four held-out environments, eight held-out questions. An external linear softmax controller received {R['controllerParameterChangingUpdates']} real NumPy Adam/REINFORCE parameter-changing updates. The API LLM received **zero** weight updates. All 128 updates were independently replayed from their original rewards, RNG samples, optimizer states and hashes.

Frozen greedy actions on TEST: {R['learnedGreedyActions']}.
Greedy mean utility: {R['learnedGreedyMeanUtility']:.6f}; learned stochastic expected utility: {R['learnedExpectedMeanUtility']:.6f}; initial uniform policy expected utility: {R['initialZeroExpectedMeanUtility']:.6f}.
Constant-operation utilities: {json.dumps(R['constantOperationMeanUtility'])}. Best constant action in this small TEST table: {best} (descriptive, selected after evaluation).

| Policy | Correct | Wrong integer | SKIP | Format failure |
|---|---:|---:|---:|---:|
{table}

Utility is not accuracy. Correct=+1, wrong integer=-1, SKIP=-0.10, invalid format=-0.25, plus frozen operation and memory-character costs. Abstaining can beat confidently wrong notes. Invalid prose is penalized less than a wrong integer, a limitation of this objective; a secondary explicit-final-answer audit is retained separately, without changing rewards or primary results.

## What was actually trained

Opaque named functions are affine, with coefficients known only to the evaluator. The LLM writes its old note from old observations and a candidate new note from recent observations; observations may be stable, changed, or insufficient. Later solving sees saved notes only, without observations or gold coefficients. All four operations (KEEP/OVERWRITE/APPEND/RETRACT) are physically saved, read back and tested by real API queries.

The controller's eight **human-designed** features include host-computed affine parsing and agreement of notes with public observations. Thus conflict checking here is supplied by a program, not learned intrinsic mathematical introspection. Actions and reward are human-designed too. The controller samples one action and trains from its real, cached subsequent-answer utility; this is offline contextual-bandit replay, not fresh LLM rollouts on every gradient. The zero-reward reference stays exactly at zero parameters with zero optimizer steps; it is not a separately sampled actor training run.

All TRAIN outcomes precede the final controller; TEST does not enter updates. For evaluation, all TEST counterfactual operations are queried, then the frozen controller selects using only its public features. Selected results refer to the real cached trials for that exact bank, not an additional live chosen-policy rollout. Small sample, one seed, one serving model, no statistical significance claim.

## Interpretation boundaries

An increase relative to a uniform untrained policy establishes only a limited outcome-driven controller effect under this reward and these features. To establish useful conditional memory management, it must also compete with constant policies and preserve correct notes. To establish better mathematical learning, it must increase correct answers; higher utility through SKIP alone is insufficient. If RETRACT wins everywhere, this is policy collapse toward abstention, not successful conditional repair.

This experiment does not train the LLM's note-writing weights. It cannot establish that the LLM independently learns how to write better notes or discovers a learning method unknown to humans. It explicitly tests whether a small external policy can learn useful operations from subsequent consequences. The original 435 example and the earlier frozen repair replication are different experiments; their positive outcomes cannot be substituted for this test.

## Reproducibility and correction

Frozen protocol, all raw model prompts/responses, memory versions, receipts, parameters and optimizer moments are included. {len(raw)} committed raw API responses, {len(attempts)} attempted POSTs, {summary['pendingUncertainAttempts']} uncertain pending attempts from interrupted sessions. No automatic retries. Logging inherited a /72 denominator from the older transport; this experiment's actual frozen cap is 112, with 100 planned calls.

Before any controller commits or TEST responses, the implementation was corrected to use the existing display normalizer for implicit multiplication such as `3x`. The 43 existing raw responses were copied unchanged; no formula or answer was replaced. Original source and correction receipt are included. Primary cases/rewards/prompts were unchanged. Original pre-correction data remain archived separately.

No credentials, authorization headers, pretrained weights, or claims of novelty, broad robustness, statistical significance or competition ranking are included.
'''
files={'README.md':report.encode(),'summary.json':json.dumps(summary,ensure_ascii=False,indent=2).encode()}
for p in OUT.rglob('*.json'):files['evidence/'+str(p.relative_to(OUT))]=p.read_bytes()
files['evidence/pre-feature-fix-source.py']=(OUT/'pre-feature-fix-source.py').read_bytes()
files['evidence/frozen-plan.json']=(L['WORK']/'frozen-plan.json').read_bytes()
for name in ('learn_memory_policy.py','analyze_policy.py','display_math.py','Lain-Zip-Apertus-API-Test.py'):files['source/'+name]=(ROOT/name).read_bytes()
for name,data in files.items():assert re.search(rb'\bsk-[A-Za-z0-9_-]{24,}\b',data) is None
manifest={name:hashlib.sha256(data).hexdigest() for name,data in files.items()};files['manifest.json']=json.dumps(manifest,indent=2).encode()
archive=ROOT/'Lain-Zip-Outcome-Memory-Policy-Review-20261014.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for name,data in files.items():z.writestr(name,data)
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 for name,h in manifest.items():assert hashlib.sha256(z.read(name)).hexdigest()==h
print(json.dumps({'zip':str(archive),'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'counts':counts,'result':{k:v for k,v in R.items() if k not in ('hash','TESTRows')}},ensure_ascii=False,indent=2))
