"""Outcome-trained memory controller on opaque, changing affine functions.

API model weights stay frozen. A separate 4-action linear softmax controller
receives real optimizer updates from real model-answer rewards in TRAIN only.
No gold operation or target formula is given to either learner.
"""
import copy,hashlib,json,re,runpy,sys,termios
from pathlib import Path
from fractions import Fraction
import numpy as np
from display_math import normalize

ROOT=Path(__file__).parent
M=runpy.run_path(str(ROOT/'Lain-Zip-Apertus-API-Test.py'),run_name='policy_api')
WORK=ROOT/'policy-learning-results';WORK.mkdir(exist_ok=True);H=M['setup'](WORK)
from cf_cases import scalar
H['scalar']=scalar
from zip_guided_helpers import normalize_surface
ACTIONS=('KEEP','OVERWRITE','APPEND','RETRACT')
STEPS=128;LR=.04;SEED=26831

def curriculum():
    # The actor sees observations, not the kind labels or hidden coefficients.
    specs=[('TRAIN','stable',2,3,2,3),('TRAIN','changed',3,1,5,2),
      ('TRAIN','incomplete',4,2,7,6),('TRAIN','stable',-2,5,-2,5),
      ('TRAIN','changed',1,4,-3,7),('TRAIN','incomplete',-1,3,6,-2),
      ('TEST','stable',5,-3,5,-3),('TEST','changed',-4,6,3,8),
      ('TEST','changed',6,-1,-2,9),('TEST','incomplete',2,8,-5,4)]
    cases=[]
    for i,(split,kind,oa,ob,a,b) in enumerate(specs):
        name='F_'+hashlib.sha256(('opaque-memory-study-'+str(i)).encode()).hexdigest()[:8]
        c={'id':'policy-case-'+str(i),'card':{'id':'policy-card-'+str(i)},'functionName':name,
           'split':split,'kindForAuditOnly':kind,'oldHiddenCoefficients':[oa,ob],
           'currentHiddenCoefficients':[a,b],'oldObservations':[[0,ob],[1,oa+ob]],
           'newObservations':[[0,b]] if kind=='incomplete' else [[0,b],[1,a+b]],
           'futureInputs':[2,4]}
        cases.append(c)
    return {'protocol':'lain-zip-outcome-memory-policy-v27','cases':cases,'actions':list(ACTIONS),
       'model':'swiss-ai/Apertus-v1.5-70B','temperature':0,'maxTokens':512,
       'plannedPOSTs':100,'maxAttemptedPOSTs':112,'controllerType':'linear softmax, sampled REINFORCE, Adam',
       'controllerSteps':STEPS,'learningRate':LR,'seed':SEED,'actorAPIWeightsUpdated':False,
       'correctValueReward':1.,'wrongIntegerReward':-1.,'skipReward':-.10,'invalidFormatReward':-.25,
       'operationCosts':{'KEEP':0.,'OVERWRITE':.10,'APPEND':.15,'RETRACT':.02},
       'memoryCharacterCost':.001,'baselineUpdateRate':.15,'zeroRewardControlNeverOptimizerSteps':True,
       'feedbackSource':'two actual future API answers per operation, exact hidden-function scoring',
       'TRAINOnlyOptimization':True,'TESTGeneratedOnlyAfterFinalControllerCommit':True,
       'responsesCachedForTrainingReplay':True,'notFreshOnPolicyLLMRolloutsAtEachGradient':True,
       'allOperationsActuallyEvaluatedByAPI':True,'APIOutputCopiedBeforeScoring':True,
       'humanSpecifiedActionsFeaturesRewards':True,'humanUnknownStrategyDiscoveryClaimed':False,
       'pretrainedFunctionNameKnowledgeNotAvailable':True,'familyAffinePublicButCoefficientsPrivate':True,
       'oldNotesStudentAuthoredFromOldObservations':True,'newNotesStudentAuthoredFromNewObservations':True,
       'obsoleteOldRulesMayHaveBeenValidInPriorEnvironment':True,'ownOriginalMathMistakeClaimed':False,
       'proposalGenerationCostCommonToAllComparedPolicies':True,'memorySizeCostIsProxyNotBilling':True,
       'statisticalSignificanceClaimed':False}

PLAN=curriculum()

def note_expression(raw):
    text=normalize_surface(normalize(raw))[0].strip()
    fence=re.fullmatch(r'```(?:python|text|math)?\s*([\s\S]*?)\s*```',text)
    if fence:text=fence.group(1).strip()
    if text.upper()=='SKIP':return None
    try:
        from zip_content_core import parse_expression
        poly,_,names=parse_expression(text)
        if set(names)-{'x'} or any(sum(power for _,power in monomial)>1 for monomial in poly):return None
        H['scalar'](text,'x',0);H['scalar'](text,'x',1)
        return text
    except (ValueError,SyntaxError,TypeError,AttributeError,ZeroDivisionError):return None

def fits(text,observations):
    expr=note_expression(text)
    return bool(expr and all(H['scalar'](expr,'x',x)==y for x,y in observations))

def features(c,old,new):
    obs=c['newObservations']
    return np.array([1.,float(note_expression(old) is not None),float(note_expression(new) is not None),
       float(fits(old,obs)),float(fits(new,obs)),float(len(obs)==2),
       min(len(old),100)/100.,min(len(new),100)/100.],dtype=np.float64)

def probabilities(weights,x):
    logits=weights@x;logits-=logits.max();p=np.exp(logits);return p/p.sum()

def memory(old,new,action):
    if action=='KEEP':return [old]
    if action=='OVERWRITE':return [] if new.strip().upper()=='SKIP' else [new]
    if action=='APPEND':return [old]+([] if new.strip().upper()=='SKIP' else [new])
    if action=='RETRACT':return []
    raise ValueError('Invalid memory operation')

def score_value(raw,expected,capped=False):
    text=raw.strip()
    if capped:return {'kind':'format','correct':False,'reward':-.25,'writtenInteger':None}
    if text.upper()=='SKIP':return {'kind':'skip','correct':False,'reward':-.10,'writtenInteger':None}
    if re.fullmatch(r'[+-]?\d+',text):
        value=int(text);correct=value==expected
        return {'kind':'integer','correct':correct,'reward':1. if correct else -1.,'writtenInteger':value}
    return {'kind':'format','correct':False,'reward':-.25,'writtenInteger':None}

def generate_case(api,c,out):
    folder=out/'cases'/c['id'];folder.mkdir(parents=True,exist_ok=True)
    if (folder/'outcomes.json').exists():return H['check_seal'](H['read'](folder/'outcomes.json'))
    notes={}
    for phase,obs in [('old_note',c['oldObservations']),('new_note',c['newObservations'])]:
        text='Opaque function '+c['functionName']+' is affine in integer input x. Its coefficients are private.\nObserved input/output pairs:\n'
        text+='\n'.join(str(x)+' -> '+str(y) for x,y in obs)
        text+='\nWrite the unique affine expression in x if these observations determine one; otherwise write SKIP. Do not invent an unobserved coefficient.'
        prompt=[{'role':'system','content':'Write your own reusable function note from observations. Return ONE expression in x using * and **, with no prose or equality chain, or SKIP if the observations are insufficient.'},{'role':'user','content':text}]
        r=api.ask(phase,c,prompt);notes[phase]=r
    old=notes['old_note']['studentOutput']['raw'];new=notes['new_note']['studentOutput']['raw']
    x=features(c,old,new);operations={}
    # Fixed rotating order reduces simple request-order confounding.
    order=list(ACTIONS);i=int(c['id'].rsplit('-',1)[-1])%4;order=order[i:]+order[:i]
    for action in order:
        bank=memory(old,new,action)
        state=H['sealed']({'action':action,'studentChosenNotes':[{'recordId':notes['old_note']['recordId'],'raw':old},{'recordId':notes['new_note']['recordId'],'raw':new}],
           'activeNotes':bank,'hostWroteNewFormula':False,'mutationIsCounterfactualOperationTrial':True})
        H['put_once'](folder/('memory-'+action+'.json'),state)
        state=H['check_seal'](H['read'](folder/('memory-'+action+'.json')));answers=[]
        for point in c['futureInputs']:
            text='Query the CURRENT opaque affine function '+c['functionName']+' at x='+str(point)+'.\n'
            text+=('Saved working notes in chronological order:\n'+'\n'.join(c['functionName']+'(x) = '+n for n in state['activeNotes'])) if state['activeNotes'] else 'There is no saved working note for this function.'
            text+='\nUse the available working notes if they determine a value. If they do not, return SKIP. No function observations or hidden coefficients are supplied here.'
            prompt=[{'role':'system','content':'Answer using only the provided working memory. Opaque function names have no built-in meaning. Return ONLY one integer, or SKIP when the value cannot be determined. Do not invent a function definition.'},{'role':'user','content':text}]
            r=api.ask('future_'+action+'_'+str(point),c,prompt)
            a,b=c['currentHiddenCoefficients'];gold=a*point+b
            scored=score_value(r['studentOutput']['raw'],gold,r['studentOutput']['tokenCapReached'])
            answers.append({'recordId':r['recordId'],'raw':r['studentOutput']['raw'],'expectedValueAuditOnly':gold,'score':scored})
        reward=sum(a['score']['reward'] for a in answers)/len(answers)
        cost=PLAN['operationCosts'][action]+PLAN['memoryCharacterCost']*sum(len(n) for n in bank)
        operations[action]={'answers':answers,'answerReward':reward,'cost':cost,'utility':reward-cost,'memoryHash':state['hash']}
    result=H['sealed']({'caseId':c['id'],'split':c['split'],'oldNoteRecordId':notes['old_note']['recordId'],'newNoteRecordId':notes['new_note']['recordId'],
       'oldRaw':old,'newRaw':new,'featureVector':x.tolist(),'featureInputsAreOnlyPublicObservationsAndOwnNotes':True,'operations':operations,
       'goldActionSuppliedToController':False,'targetFormulaSuppliedToActor':False})
    H['put_once'](folder/'outcomes.json',result)
    print('CASE '+json.dumps({'id':c['id'],'split':c['split'],'old':old,'new':new,'utilities':{a:round(o['utility'],3) for a,o in operations.items()}},ensure_ascii=False),flush=True)
    return result

def train_controller(train,out):
    commit_dir=out/'controller-commits';commit_dir.mkdir(exist_ok=True)
    rng=np.random.default_rng(SEED);weights=np.zeros((4,8));mom=np.zeros_like(weights);var=np.zeros_like(weights)
    baseline=np.zeros(len(train));zero=np.zeros_like(weights);commits=[];parameter_changes=0
    schedule=np.tile(np.arange(len(train)),(STEPS+len(train)-1)//len(train))[:STEPS]
    for block in range(0,len(schedule),len(train)):rng.shuffle(schedule[block:block+len(train)])
    for step,index in enumerate(schedule,1):
        row=train[int(index)];x=np.asarray(row['featureVector']);p=probabilities(weights,x)
        u=float(rng.random());action=min(int(np.searchsorted(np.cumsum(p),u)),3)
        reward=row['operations'][ACTIONS[action]]['utility'];before=weights.copy();b=float(baseline[index]);advantage=reward-b
        # Gradient of -advantage*log softmax(choice); actual, not mirrored tests.
        g=p.copy();g[action]-=1;gradient=advantage*g[:,None]*x[None,:]
        mom=.9*mom+.1*gradient;var=.999*var+.001*gradient**2
        weights-=LR*(mom/(1-.9**step))/(np.sqrt(var/(1-.999**step))+1e-8)
        baseline[index]=.85*baseline[index]+.15*reward
        changed=not np.array_equal(before,weights);parameter_changes+=int(changed)
        receipt=H['sealed']({'step':step,'TRAINCaseId':row['caseId'],'chosenOperation':ACTIONS[action],'samplingUniform':u,'samplingProbabilities':p.tolist(),
          'realOutcomeReward':reward,'sourceOutcomeHash':row['hash'],'baselineBefore':b,'advantage':advantage,'gradientNorm':float(np.linalg.norm(gradient)),
          'beforeWeightHash':H['digest'](before.tolist()),'afterWeightHash':H['digest'](weights.tolist()),'parametersChanged':changed,
          'weights':weights.tolist(),'adamFirstMoment':mom.tolist(),'adamSecondMoment':var.tolist(),'zeroRewardWeights':zero.tolist(),
          'zeroRewardOptimizerSteps':0,'APIModelWeightsUpdated':False})
        H['put_once'](commit_dir/('step-'+str(step).zfill(4)+'.json'),receipt);commits.append(receipt)
    final=H['sealed']({'complete':True,'steps':STEPS,'parameterChangingUpdates':parameter_changes,'weights':weights.tolist(),
      'weightHash':H['digest'](weights.tolist()),'zeroRewardWeights':zero.tolist(),'zeroRewardOptimizerSteps':0,
      'APIModelWeightsUpdated':False,'lastCommitHash':commits[-1]['hash'],'trainedBeforeAnyTESTAnswers':True})
    H['put_once'](out/'final-controller.json',final);return final

def run(key):
    binding=H['digest']({'plan':PLAN,'code':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()})
    out=WORK/('zip-policy-'+binding[:12]);out.mkdir(exist_ok=True)
    H['put_once'](out/'protocol.json',H['sealed']({'plan':PLAN,'binding':binding,'baseURL':'https://api.inference.cscs.ch/v1'}))
    cfg={'key':key,'url':'https://api.inference.cscs.ch/v1','model':PLAN['model'],'token_field':'max_tokens','budget':512,'extra':{'temperature':0}}
    api=M['API'](cfg,out,H)
    # The generic transport's cap is task-specific for this independently
    # authorized experiment, not a modification to earlier committed studies.
    api.ask.__func__.__globals__['PLAN']=dict(M['PLAN'],maxCalls=112)
    train=[generate_case(api,c,out) for c in PLAN['cases'] if c['split']=='TRAIN']
    final=H['check_seal'](H['read'](out/'final-controller.json')) if (out/'final-controller.json').exists() else train_controller(train,out)
    weights=np.asarray(final['weights']);frozen_hash=H['digest'](weights.tolist());tests=[]
    for c in PLAN['cases']:
        if c['split']!='TEST':continue
        row=generate_case(api,c,out);x=np.asarray(row['featureVector']);p=probabilities(weights,x);choice=int(np.argmax(p))
        decision=H['sealed']({'caseId':c['id'],'action':ACTIONS[choice],'probabilities':p.tolist(),'weightHash':frozen_hash,
           'featureVector':x.tolist(),'TESTRewardUsedForSelection':False,'sampleIsGreedyNotRandom':True})
        H['put_once'](out/'TEST-decisions'/(c['id']+'.json'),decision)
        # Execute and persist the frozen controller's actual operation, then
        # read the resulting bank. Real answer originals for that exact bank
        # are referenced from the precomputed operation trials, not fabricated.
        bank=H['sealed']({'decisionHash':decision['hash'],'action':decision['action'],'activeNotes':memory(row['oldRaw'],row['newRaw'],decision['action']),
           'sourceFutureAnswerRecordIds':[a['recordId'] for a in row['operations'][decision['action']]['answers']]})
        H['put_once'](out/'TEST-policy-memory'/(c['id']+'.json'),bank)
        H['check_seal'](H['read'](out/'TEST-policy-memory'/(c['id']+'.json')))
        utilities=np.array([row['operations'][a]['utility'] for a in ACTIONS])
        tests.append({'caseId':c['id'],'decision':decision,'greedyUtility':float(utilities[choice]),'expectedLearnedUtility':float(p@utilities),
           'expectedInitialZeroUtility':float(utilities.mean()),'actionUtilities':dict(zip(ACTIONS,utilities.tolist())),
           'selectedAnswerCorrect':sum(a['score']['correct'] for a in row['operations'][decision['action']]['answers']),
           'allOperationAnswerCorrect':{a:sum(v['score']['correct'] for v in row['operations'][a]['answers']) for a in ACTIONS}})
    assert H['digest'](weights.tolist())==frozen_hash
    baseline={a:sum(x['actionUtilities'][a] for x in tests)/len(tests) for a in ACTIONS}
    correct={a:sum(x['allOperationAnswerCorrect'][a] for x in tests) for a in ACTIONS}
    result=H['sealed']({'complete':True,'model':PLAN['model'],'TRAINCases':6,'TESTCases':4,'TESTQueries':8,
       'controllerOptimizerSteps':STEPS,'controllerParameterChangingUpdates':final['parameterChangingUpdates'],'APIModelWeightUpdates':0,
       'zeroRewardOptimizerSteps':0,'learnedGreedyActions':[x['decision']['action'] for x in tests],
       'learnedGreedyMeanUtility':sum(x['greedyUtility'] for x in tests)/len(tests),
       'learnedExpectedMeanUtility':sum(x['expectedLearnedUtility'] for x in tests)/len(tests),
       'initialZeroExpectedMeanUtility':sum(x['expectedInitialZeroUtility'] for x in tests)/len(tests),
       'constantOperationMeanUtility':baseline,'learnedSelectedCorrectAnswers':sum(x['selectedAnswerCorrect'] for x in tests),
       'constantOperationCorrectAnswers':correct,'actualAPIRequests':len(list((out/'attempts').glob('*.json'))),
       'frozenControllerHash':frozen_hash,'TESTRows':tests,'statisticalSignificanceClaimed':False,'humanUnknownLearningStrategyClaimed':False,
       'supportsPolicyLearningOnlyIfHeldoutUtilityImproves':True,'replayOfCollectedActionOutcomesNotFullOnlineLLMTraining':True})
    H['put_once'](out/'result.json',result)
    print(json.dumps({k:v for k,v in result.items() if k not in ('hash','TESTRows')},ensure_ascii=False,indent=2),flush=True)
    print('OUTPUT '+str(out),flush=True)

def preflight():
    # Meaningful analytic-gradient check and scope/uncertainty tests.
    x=np.array([1.,1.,0.,.5,0.,1.,0.,.2]);w=np.arange(32).reshape(4,8)/100.;a=2;adv=.7
    p=probabilities(w,x);g=p.copy();g[a]-=1;analytic=adv*g[:,None]*x[None,:]
    for i,j in [(0,0),(1,3),(2,5),(3,7)]:
        plus=w.copy();minus=w.copy();plus[i,j]+=1e-6;minus[i,j]-=1e-6
        numerical=(-adv*np.log(probabilities(plus,x)[a])+adv*np.log(probabilities(minus,x)[a]))/2e-6
        assert abs(numerical-analytic[i,j])<1e-7
    assert note_expression('3*x + 2') is not None
    assert note_expression('3x + 2')=='3*x + 2'
    assert fits('3x + 1',[[0,1],[1,4]])
    assert not fits('5x + 3',[[0,3],[1,5]])
    assert note_expression('x**2') is None
    assert note_expression('SKIP') is None
    assert fits('2*x+3',[[0,3],[1,5]])
    assert not fits('2*x+3',[[0,4]])
    assert score_value('SKIP',99)['kind']=='skip'
    assert not score_value('3',4)['correct']
    assert memory('2*x+3','SKIP','RETRACT')==[]
    assert memory('2*x+3','4*x+5','OVERWRITE')==['4*x+5']
    assert sum(c['split']=='TRAIN' for c in PLAN['cases'])==6
    assert sum(c['split']=='TEST' for c in PLAN['cases'])==4
    H['put_once'](WORK/'frozen-plan.json',H['sealed'](PLAN))
    print('Preflight passed: finite-difference gradients, affine scope, note mutations and 6/4 split. Real API calls=0. Plan frozen.',flush=True)

if __name__=='__main__':
    if '--preflight' in sys.argv:preflight()
    else:
        fd=sys.stdin.fileno();old=termios.tcgetattr(fd);new=list(old);new[3]&=~termios.ECHO
        termios.tcsetattr(fd,termios.TCSANOW,new);print('AUTH_INPUT_READY',flush=True)
        try:key=sys.stdin.readline().strip()
        finally:termios.tcsetattr(fd,termios.TCSANOW,old)
        try:
            frozen=H['check_seal'](H['read'](WORK/'frozen-plan.json'))
            assert {k:v for k,v in frozen.items() if k!='hash'}==PLAN
            run(key)
        except Exception as e:print('RUN_STOPPED '+(str(e) if type(e) is RuntimeError else type(e).__name__),flush=True);sys.exit(1)
        finally:key=None
