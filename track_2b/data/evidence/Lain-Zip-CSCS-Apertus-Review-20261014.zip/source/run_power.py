import sys,termios,runpy,json
from pathlib import Path
fd=sys.stdin.fileno();old=termios.tcgetattr(fd);new=list(old);new[3]&=~termios.ECHO
termios.tcsetattr(fd,termios.TCSANOW,new);print('AUTH_INPUT_READY',flush=True)
try:key=sys.stdin.readline().strip()
finally:termios.tcsetattr(fd,termios.TCSANOW,old)
m=runpy.run_path(str(Path(__file__).with_name('Lain-Zip-Apertus-API-Test.py')),run_name='zip_api_runtime')
work=Path(__file__).parent/'results';h=m['setup'](work);c=m['PLAN']['cases'][0]
cfg={'key':key,'url':'https://api.inference.cscs.ch/v1','model':'swiss-ai/Apertus-v1.5-70B','token_field':'max_tokens','budget':1024,'extra':{'temperature':0}}
out=work/'zip-apertus-power-70b';out.mkdir(exist_ok=True)
prior=work/'zip-apertus-natural-70b';parent=h['check_seal'](h['read'](prior/'result.json'))
record=[h['read'](p) for p in (prior/'raw').glob('*.json')][0]
h['put_once'](out/'protocol.json',h['sealed']({'model':cfg['model'],'parentResultHash':parent['hash'],'parentRetractionRecordId':record['recordId'],'teacherReplacementSupplied':False,'operationInstruction':'represent repeated identical factors using powers','exploratoryAfterCollectAmbiguity':True,'oneFollowupOnly':True,'combinedMaxCalls':72,'ownOriginalAuthor':False}))
api=m['API'](cfg,out,h);orig=api.ask
def ask(*a,**kw):
 if len(list(work.glob('*/attempts/*.json')))>=72:raise RuntimeError('Combined 72-attempt cap reached')
 return orig(*a,**kw)
api.ask=ask
try:
 if parent['action']!='RETRACT':raise RuntimeError('Actual student withdrawal required')
 before=h['initial'](c['card']);d={k:v for k,v in record.items() if k!='hash'};d['action']=parent['action']
 after=h['apply_action'](before,h['sealed'](d))
 messages=[{'role':'system','content':'Rewrite a product by representing repeated identical factors using powers. Preserve its mathematical value for every real input. Return ONE expression using * and **, without prose or an equality chain.'},{'role':'user','content':'You withdrew a previous notebook rule. Write your own replacement from the ORIGINAL product: 435 * v * v. v is real. No replacement formula is supplied.'}]
 proposal=api.ask('power_editor',c,messages);audit=h['proposal_audit'](c,proposal)
 after=h['attach_proposal'](after,proposal,audit)
 h['put_once'](out/'replacement-audit.json',h['sealed'](audit));h['put_once'](out/'old-note.json',before);h['put_once'](out/'new-note.json',after)
 after=h['check_seal'](h['read'](out/'new-note.json'));follow=None;strict=False
 if audit['accepted']:
    task,prompt=h['followup'](after,'q',False,1)
    prompt[0]['content']='Apply the retrieved saved ZIP when valid. Represent repeated identical factors using powers. Return ONE expression using * and ** without prose or an equality chain.'
    r=api.ask('persisted_rule_follow_q',c,prompt);a=h['math_audit'](task,r);strict=bool(a['correctChangedExpression'] and a['fullAudit']['correctSimplifiedAnswer'])
    follow={'recordId':r['recordId'],'raw':r['studentOutput']['raw'],'audit':a,'strictCollectedAnswerCorrect':strict}
 row=h['sealed']({'complete':True,'model':cfg['model'],'exploratory':True,'inheritedNote':True,'actualParentAction':parent['action'],'proposalRaw':proposal['studentOutput']['raw'],'replacementAccepted':audit['accepted'],'studentReplacement':audit['studentFinal'],'followup':follow,'candidateOneFollowupClosedLoop':audit['accepted'] and strict,'predeclaredTwoFollowupCriterionMet':False,'differentPromptOperationSpecified':True,'ownUnnoticedErrorRepairProven':False,'memoryBenefitOverMatchedNoNoteControlProven':False})
 h['put_once'](out/'result.json',row);print(json.dumps({k:v for k,v in row.items() if k not in ('followup','hash')},ensure_ascii=False),flush=True)
except Exception as e:print('RUN_STOPPED '+(str(e) if type(e) is RuntimeError else type(e).__name__),flush=True)
finally:key=None;cfg['key']=None
