import sys,termios,runpy,json,re
from pathlib import Path
fd=sys.stdin.fileno();old=termios.tcgetattr(fd);new=list(old);new[3]&=~termios.ECHO
termios.tcsetattr(fd,termios.TCSANOW,new);print('AUTH_INPUT_READY',flush=True)
try:key=sys.stdin.readline().strip()
finally:termios.tcsetattr(fd,termios.TCSANOW,old)
m=runpy.run_path(str(Path(__file__).with_name('Lain-Zip-Apertus-API-Test.py')),run_name='zip_api_runtime')
work=Path(__file__).parent/'results';h=m['setup'](work);c=m['PLAN']['cases'][0]
try:
 for size,source in [('70B','zip-apertus-70b-targeted-435'),('8B','zip-apertus-api-871b6ebb8b30')]:
    cfg={'key':key,'url':'https://api.inference.cscs.ch/v1','model':'swiss-ai/Apertus-v1.5-'+size,'token_field':'max_tokens','budget':1024,'extra':{'temperature':0}}
    records=[h['read'](p) for p in (work/source/'raw').glob('*.json')]
    properties={}
    for role in ('left_sign','right_sign'):
        properties[role]=next(r for r in records if r['phase']==role and r['caseCardId']==c['card']['id'])
    out=work/('zip-apertus-natural-'+size.lower());out.mkdir(exist_ok=True)
    h['put_once'](out/'protocol.json',h['sealed']({'model':cfg['model'],'case':c,'sourceCase':source,'checkRecordIds':{k:v['recordId'] for k,v in properties.items()},'exploratoryAfterStructuredFailures':True,'temperature':0,'studentFactorCountsOmitted':True,'oldNoteInherited':True,'noTeacherReplacementFormula':True,'maxCallsPerModel':3,'combinedMaxCalls':72}))
    api=m['API'](cfg,out,h);orig=api.ask
    def ask(*a,**kw):
        if len(list(work.glob('*/attempts/*.json')))>=72:raise RuntimeError('Combined 72-attempt cap reached')
        return orig(*a,**kw)
    api.ask=ask
    text='Saved candidate ZIP for all real v:\n435 * v * v = 435^2\nYour independently recorded checks at the SAME input v=0:\nLeft: '+properties['left_sign']['studentOutput']['raw']+'\nRight: '+properties['right_sign']['studentOutput']['raw']+'\nReview whether the note and your checks can both be valid. Decide whether to retain or withdraw the universal rule. If you withdraw it, collect the ORIGINAL product 435 * v * v and write your own replacement expression. No replacement answer is provided.'
    prompt=[{'role':'system','content':'Review your algebra notebook using your own recorded evidence. Return ONLY valid JSON with action (KEEP or RETRACT), reason (your brief reflection), replacement (one expression in Python notation using * and **, or null if KEEP). Do not include an equality chain in replacement.'},{'role':'user','content':text}]
    r=api.ask('natural_revision',c,prompt);raw=r['studentOutput']['raw'].strip();obj=None
    try:obj=json.loads(raw)
    except (ValueError,TypeError):
        fence=re.fullmatch(r'```(?:json)?\s*([\s\S]*?)\s*```',raw)
        if fence:
            try:obj=json.loads(fence.group(1))
            except (ValueError,TypeError):pass
    before=h['initial'](c['card']);after=before;accepted=False;action=None;follow=[]
    if isinstance(obj,dict) and obj.get('action') in ('KEEP','RETRACT') and not r['studentOutput']['tokenCapReached']:
        action=obj['action'];decision={k:v for k,v in r.items() if k!='hash'};decision['action']=action
        after=h['apply_action'](before,h['sealed'](decision))
        if action=='RETRACT' and isinstance(obj.get('replacement'),str):
            # A declared JSON field is an extraction, not a host-created formula.
            proposal=h['sealed']({'recordId':r['recordId']+'-json-replacement','caseCardId':c['card']['id'],'sourceRecordId':r['recordId'],'sourceRecordHash':r['hash'],'extractionKind':'exact declared JSON replacement field','originalAPIOutputUntouched':True,'studentOutput':{'raw':obj['replacement'],'tokenCapReached':False}})
            h['put_once'](out/'extracted-proposal.json',proposal)
            audit=h['proposal_audit'](c,proposal);accepted=audit['accepted'];after=h['attach_proposal'](after,proposal,audit)
            h['put_once'](out/'proposal-audit.json',h['sealed'](audit))
    h['put_once'](out/'old-note.json',before);h['put_once'](out/'new-note.json',after)
    after=h['check_seal'](h['read'](out/'new-note.json'))
    if accepted:
        for variable,multiplier in [('q',1),('z',2)]:
            task,messages=h['followup'](after,variable,False,multiplier)
            answer=api.ask('natural_follow_'+variable,c,messages);audit=h['math_audit'](task,answer)
            strict=bool(audit['correctChangedExpression'] and audit['fullAudit']['correctSimplifiedAnswer'])
            follow.append({'variable':variable,'recordId':answer['recordId'],'audit':audit,'strictCollectedAnswerCorrect':strict})
    row=h['sealed']({'complete':True,'model':cfg['model'],'action':action,'replacementAccepted':accepted,'studentJSON':obj,'followup':follow,'strictFollowupCorrect':sum(x['strictCollectedAnswerCorrect'] for x in follow),'candidateClosedLoop':accepted and action=='RETRACT' and len(follow)==2 and all(x['strictCollectedAnswerCorrect'] for x in follow),'ownErrorRepairClaimed':False,'exploratory':True})
    h['put_once'](out/'result.json',row)
    print(json.dumps({k:v for k,v in row.items() if k not in ('followup','hash')},ensure_ascii=False),flush=True)
except Exception as e:
 print('RUN_STOPPED '+(str(e) if type(e) is RuntimeError else type(e).__name__),flush=True)
finally:
 key=None
