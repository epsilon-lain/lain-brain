import json,hashlib,zipfile,runpy,re
from pathlib import Path
root=Path(__file__).parent;results=root/'results'
m=runpy.run_path(str(root/'Lain-Zip-Apertus-API-Test.py'),run_name='review_build');h=m['setup'](results)
primary=h['read'](results/'zip-apertus-api-871b6ebb8b30'/'result.json')
strong=h['read'](results/'zip-apertus-70b-targeted-435'/'result.json')
success=h['read'](results/'zip-apertus-display-recovery-70b'/'result.json')
paths=sorted(p for p in results.glob('zip-*/**/*.json') if p.is_file())
checked=0
for p in paths:
 d=h['read'](p)
 if isinstance(d,dict) and 'hash' in d:h['check_seal'](d);checked+=1
raws=[h['read'](p) for p in results.glob('zip-*/raw/*.json')]
attempts=list(results.glob('zip-*/attempts/*.json'))
assert len(attempts)==72 and len(raws)==72
assert all(h['read'](p)['status']=='committed' for p in attempts)
assert success['candidateOneFollowupClosedLoop'] and success['followup']['strictCollectedAnswerCorrect']
# Inspect and certify only the mathematical content of the actual formal note;
# the natural language reflection remains a separately reviewed draft.
summary={'complete':True,'actualAPIRequests':72,'savedRawResponses':72,'trainingUpdates':0,'models':sorted({r['responseModel'] for r in raws}),
 'primary8B':{k:primary[k] for k in ('correctGroundedChecks','inheritedDecisiveCases','withdrawals','verifiedNewFormulas','candidateClosedLoops','correctEvidenceControls','evidenceControls')},
 'structured70B':{'caseCount':1,'groundedConflict':strong['row']['groundedContradiction'],'action':strong['row']['afterAction'],'replacementAccepted':strong['row']['replacementAccepted'],'candidateClosedLoop':strong['row']['candidateClosedLoop']},
 'exploratory70B':{'candidateOneFollowupClosedLoop':True,'oldNote':'435 * v * v = 435^2','studentAction':'RETRACT','studentNewRuleRaw':'v² * 435','notationNormalized':'v**2 * 435','followupRaw':success['followup']['originalRaw'],'strictFollowupCorrect':True,'followupCount':1,'actualNoteSavedAndReadBack':True},
 'gradingCorrection':'Superscript digits are mathematical display notation; original raw responses were preserved. No coefficient, variable, factor, or answer was filled in.',
 'humanReviewOfSuccessfulParentReflection':'The 70B natural-revision reason correctly identifies the same-input zero/positive contradiction. It does not assert the extra incorrect v=435 condition seen in the separate 8B draft.',
 'rejectedOriginalPromptAndParserResultsPreserved':True,'predeclaredTwoFollowupCriterionMet':False,'ownUnnoticedErrorRepairProven':False,'causalMemoryBenefitProven':False,'trainingImprovementProven':False,'generalRobustnessProven':False,'statisticalSignificanceClaimed':False,'postHocExploratoryChanges':True,'sealedRecordsChecked':checked,'totalCompletionTokens':sum((r.get('usage') or {}).get('completion_tokens',0) for r in raws)}
out=root/'Lain-Zip-CSCS-Apertus-Review-20261014.zip'
report='''# CSCS Apertus API: real note-revision diagnostic, 2026-10-14

72 actual authenticated chat-completion requests completed; 72 untouched raw responses saved. No training updates or local student-weight loading occurred. Requested and returned models were Apertus v1.5 8B and 70B. All earlier failures are included, not replaced by the exploratory success.

## Observed results

The predeclared five-episode 8B test correctly computed the decisive zero/positive checks for both wrong rules, but withdrew neither rule. All three evidence controls returned KEEP. The separate 70B replay withdrew the real 435 wrong note but initially supplied an invalid replacement. Structured factor outputs also had format failures; these are interface failures rather than evidence of missing mathematical knowledge.

Exploratory natural-note review (with temperature 0 and the model's own previously recorded checks) made both models choose RETRACT, but both left the replacement field null. Separate prompts saying “collect” produced unchanged products, which were rightly rejected as a newly collected rule. Specifying the operation “represent repeated identical factors using powers” made 70B write `v² * 435`. The original ASCII-only auditor rejected this correct mathematical notation. A narrowly scoped display conversion (`²` to `**2`) admitted precisely the model's own expression; it inserted no missing factor or answer.

## One minimal inherited-memory repair instance

1. Genuine old 0.5B ZIP: `435 * v * v = 435^2`, claimed for every real v.
2. 70B independently classified the original left side at v=0 as ZERO and the saved right side at the same v=0 as POSITIVE.
3. Its natural-review JSON action was RETRACT, with a correct short reason citing that contradiction.
4. Its own subsequent power-rewrite output was `v² * 435`; exact rational polynomial checking confirms equivalence to the original product.
5. A new formal note was committed to disk and read back. Its expression `v**2 * 435` is a notation conversion of the raw model expression, not a teacher-provided replacement.
6. On a newly bound variable q, given the reloaded note, it wrote `435 * q * q = q² * 435`. Both the equality and collected final expression pass the display-normalized polynomial audit.

This is an exploratory, assisted, one-follow-up existence instance of repairing inherited erroneous memory and reusing the repaired rule. It is not the originally predeclared two-follow-up success criterion. The error was authored by the earlier 0.5B student, not by 70B itself. The API 8B cold answer before seeing the note was already correct. No broad spontaneous self-correction, own-unnoticed-error repair, training gain, isolated causal memory benefit, or statistical significance is established. Prompts and sampling changed during the exploratory diagnostics; all changes and parent evidence IDs are recorded.

The natural language drafts are not automatically certified. In particular, the separate 8B natural-review draft incorrectly asserted validity only at v=435; the successful 70B parent reason contains no such assertion. An earlier structured 70B reflection also miscomputed the numeric square. These raw errors remain available for review.

## Contents

- `summary.json`: compact audit-backed results and limitations.
- `results/`: all prompt bodies, actual outputs, API model IDs/usage, attempt receipts, case summaries, memory versions, and mathematical audits.
- `source/`: the exact standalone API runtime and exploratory runner source. Secrets are supplied through non-echoing terminal input, not embedded in these files.
- `manifest.json`: SHA-256 hashes of all enclosed evidence and source files.

No API key, authorization header, model weights, or secret transcript is included.
'''
files={'summary.json':json.dumps(summary,ensure_ascii=False,indent=2).encode(),'README.md':report.encode()}
for p in paths:files['results/'+str(p.relative_to(results))]=p.read_bytes()
for p in [root/'available-models.json']:
 if p.exists():files[p.name]=p.read_bytes()
for p in root.glob('*.py'):files['source/'+p.name]=p.read_bytes()
manifest={n:hashlib.sha256(b).hexdigest() for n,b in files.items()}
files['manifest.json']=json.dumps(manifest,indent=2).encode()
for name,content in files.items():
 assert re.search(rb'\bsk-[A-Za-z0-9_-]{24,}\b',content) is None, 'Secret must not be persisted'
with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED) as z:
 for name,content in files.items():z.writestr(name,content)
with zipfile.ZipFile(out) as z:
 assert z.testzip() is None
 for n,expected in manifest.items():assert hashlib.sha256(z.read(n)).hexdigest()==expected
(root/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2))
print(json.dumps({'zip':str(out),'bytes':out.stat().st_size,'requests':len(attempts),'sealedChecked':checked,'manifestEntries':len(manifest),'sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'completionTokens':summary['totalCompletionTokens']},ensure_ascii=False))
