import sys,termios,runpy,json
from pathlib import Path

# Secret enters only through the terminal input with echo disabled. It is not
# embedded in a file, shell command, protocol, review ZIP, or public repository.
fd=sys.stdin.fileno();old=termios.tcgetattr(fd);new=list(old);new[3]&=~termios.ECHO
termios.tcsetattr(fd,termios.TCSANOW,new)
print('AUTH_INPUT_READY',flush=True)
try:key=sys.stdin.readline().strip()
finally:termios.tcsetattr(fd,termios.TCSANOW,old)
entry=Path(__file__).with_name('Lain-Zip-Apertus-API-Test.py')
m=runpy.run_path(str(entry),run_name='zip_api_runtime')
cfg={'key':key,'url':'https://api.inference.cscs.ch/v1','model':None,'token_field':'max_tokens','budget':1024,'extra':{}}
try:
    listing=m['request'](cfg,'/models')
    available=[x.get('id','') for x in listing.get('data',[]) if isinstance(x,dict)]
    print('AVAILABLE_MODELS '+json.dumps(available),flush=True)
    Path(__file__).with_name('available-models.json').write_text(json.dumps(available,indent=2))
    options=[x for x in available if 'apertus' in x.lower() and '0.5' not in x and 'thinking' not in x.lower()]
    options.sort(key=lambda x:('1.5' not in x,'8b' not in x.lower(),x))
    if not options:raise RuntimeError('No available non-thinking Apertus model')
    ns={'ZIP_API_WORK':str(Path(__file__).parent/'results'),'ZIP_API_CONFIG':{'api_key':key,'base_url':cfg['url'],'model':options[0]}}
    result=m['run'](ns)
    if result is None:sys.exit(2)
except Exception as e:
    # Keep only sanitized messages from our API adapter. Unknown exception reprs
    # are not logged, as clients can attach request objects to them.
    if type(e) is RuntimeError:print('RUN_STOPPED '+str(e),flush=True)
    else:print('RUN_STOPPED '+type(e).__name__,flush=True)
    sys.exit(1)
finally:
    key=None;cfg['key']=None
