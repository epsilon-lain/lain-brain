"""Frozen follow-up: 5 rules, 6 episodes, matched no/old/new memory arms.

No successful-case selection, no prompt tuning during execution, no weights
updated, no correct formula or evaluator feedback enters a model prompt.
"""
import copy,json,re,runpy,sys,termios,hashlib
from pathlib import Path
from display_math import normalize

ROOT=Path(__file__).parent
M=runpy.run_path(str(ROOT/'Lain-Zip-Apertus-API-Test.py'),run_name='frozen_api')
WORK=ROOT/'replication-results';WORK.mkdir(exist_ok=True)
H=M['setup'](WORK)

def designed(left,right,point,truth,kind):
    card={'left':left,'right':right,'variable':'v','family':kind,'knownExactIdentity':truth,
          'provenance':{'kind':'predeclared_designed_note','studentAuthoredVariant':False}}
    card['id']='fixed-rule-'+H['digest'](card)[:16]
    return {'id':'fixed-case-'+H['digest']({'card':card,'point':point})[:16],
            'card':card,'leftPoint':point,'rightPoint':point,'kind':'correct_rule' if truth else 'counterexample','split':'frozen_replication'}

def plan():
    a=copy.deepcopy(M['PLAN']['cases'][0]);a['id']='fixed-source-435';a['split']='source_replay'
    b=designed('4 * v * v','4**2',0,False,'drop_variable')
    c=designed('3 * (3 * v + 2)','9 * v + 2','-2/9',False,'missed_distribution_constant')
    d=copy.deepcopy(M['PLAN']['cases'][2]);d['id']='fixed-source-315';d['kind']='correct_rule';d['split']='source_replay'
    e=designed('3 * (3 * v + 2)','9 * v + 6','-2/9',True,'correct_distribution')
    rules=[a,b,c,d,e]
    for x in rules:
        assert H['property_truth'](x,'left_sign') in ('ZERO','POSITIVE','NEGATIVE')
        assert H['property_truth'](x,'right_sign') in ('ZERO','POSITIVE','NEGATIVE')
        from rr_sources import equal
        assert equal(x['card']['left'],x['card']['right'])==x['card']['knownExactIdentity']
        assert (H['property_truth'](x,'left_sign')!=H['property_truth'](x,'right_sign')) == (not x['card']['knownExactIdentity'])
    episodes=[{'case':x,'repeat':1} for x in rules]+[{'case':a,'repeat':2}]
    return {'protocol':'lain-zip-frozen-memory-repair-v26','rules':rules,'episodes':episodes,
      'model':'swiss-ai/Apertus-v1.5-70B','temperature':0,'maxTokens':1024,'maxAttemptedPOSTs':72,
      'plannedMaximumPOSTs':65,'weightsUpdated':0,'heldoutCheckpointSelection':False,
      'fiveRuleUnitsNotSixIndependentRules':True,'source435AlreadyExplored':True,
      'twoRulesGenuineOldStudentNotesThreeDesigned':True,
      'twoErrorFamilies':True,'correctAnswersNeverPrompted':True,'decisionFreeJSON':True,
      'actorMemoryEditsNotOracleEdits':True,'parentMathAuditNotShownToModel':True,
      'correctReplacementAdmittedOnlyAfterStudentRetraction':True,
      'showSuperscriptNotationAsPowersOnly':True,'noImplicitMissingFactorsInserted':True,
      'coldBeliefAssessmentOncePerRule':True,'ordinaryNoWitnessReviewOncePerRule':True,
      'allThreeMathArmsTwoFollowupsPerEpisode':True,
      'followupArmOrder':'alternating cyclic order across episodes, fixed before generation',
      'spontaneousSearchNotTested':True,'apiModelAuthoredInitialMistakesNotClaimed':True,
      'statisticalSignificanceNotClaimed':True,'scope':'exact rational real-polynomial identities'}

PLAN=plan()
# 5 cold assessments + 6 episodes * (2 sign checks + decision + 0/1 editor
# + 6 matched math calls) = at most 65 POSTs. Max 72 includes interrupted calls.

def json_object(text):
    text=text.strip();f=re.fullmatch(r'```(?:json)?\s*([\s\S]*?)\s*```',text)
    if f:text=f.group(1)
    try:o=json.loads(text)
    except (ValueError,TypeError):return None
    return o if isinstance(o,dict) else None

def display_record(r):
    return H['sealed']({'recordId':r['recordId']+'-display','caseCardId':r['caseCardId'],
      'sourceRecordId':r['recordId'],'sourceRecordHash':r['hash'],'originalRaw':r['studentOutput']['raw'],
      'presentationOnly':True,'studentOutput':{'raw':normalize(r['studentOutput']['raw']),
      'tokenCapReached':r['studentOutput']['tokenCapReached']}})

def strict_math(task,record):
    a=H['math_audit'](task,display_record(record))
    return {'audit':a,'strictCorrect':bool(a['correctChangedExpression'] and a['fullAudit']['correctSimplifiedAnswer'])}

def follow_prompt(memory,variable,multiplier,no_note=False):
    task,p=H['followup'](memory,variable,no_note,multiplier)
    p[0]['content']='Simplify the requested expression: expand products over sums, combine constant coefficients and like terms, and represent repeated identical factors using powers. A saved ZIP is a candidate tool, not a guaranteed theorem. Return ONE expression using * and **, without prose or an equality chain; if unsure write SKIP.'
    return task,p

def run(key):
    binding=H['digest']({'plan':PLAN,'codeSHA256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'baseURL':'https://api.inference.cscs.ch/v1'})
    out=WORK/('zip-fixed-'+binding[:12]);out.mkdir(exist_ok=True)
    H['put_once'](out/'protocol.json',H['sealed']({'plan':PLAN,'binding':binding}))
    cfg={'key':key,'url':'https://api.inference.cscs.ch/v1','model':PLAN['model'],'token_field':'max_tokens','budget':1024,'extra':{'temperature':0}}
    api=M['API'](cfg,out,H)
    cold={};rows=[]
    for c in PLAN['rules']:
        p=[{'role':'system','content':'Assess the validity of a candidate saved algebra rule. Return ONLY JSON with validity (VALID, INVALID, or UNSURE), and reason (brief). No checks or evaluator feedback are supplied.'},
           {'role':'user','content':'Candidate ZIP for every real '+c['card']['variable']+':\n'+c['card']['left']+' = '+c['card']['right']}]
        r=api.ask('cold_belief',c,p);o=json_object(r['studentOutput']['raw'])
        cold[c['card']['id']]={'recordId':r['recordId'],'raw':r['studentOutput']['raw'],'parsed':o,
           'notInitiallyRecognizedAsInvalid':not (o and o.get('validity')=='INVALID')}
    for index,entry in enumerate(PLAN['episodes']):
        c=copy.deepcopy(entry['case']);c['id']+='-repeat-'+str(entry['repeat'])
        folder=out/'episodes'/c['id'];folder.mkdir(parents=True,exist_ok=True)
        if (folder/'summary.json').exists():rows.append(H['check_seal'](H['read'](folder/'summary.json')));continue
        before=H['initial'](c['card']);props={};prop_records={}
        H['put_once'](folder/'00-old-note.json',before)
        for role in ('left_sign','right_sign'):
            r,a=api.choose(role,c,H['property_prompt'](c,role),('ZERO','POSITIVE','NEGATIVE'))
            props[role]=a or 'INVALID';prop_records[role]=r
        user='Candidate saved ZIP for every real '+c['card']['variable']+':\n'+c['card']['left']+' = '+c['card']['right']
        user+='\nYour independently recorded checks at the SAME input '+c['card']['variable']+'='+str(c['leftPoint'])+':\nLeft: '+prop_records['left_sign']['studentOutput']['raw']+'\nRight: '+prop_records['right_sign']['studentOutput']['raw']
        user+='\nReview whether the note and your own recorded checks can both be valid. Decide whether to retain or withdraw the universal rule. Finite agreement alone does not prove an identity.'
        p=[{'role':'system','content':'Review your algebra notebook using your own recorded evidence. Return ONLY JSON with action (KEEP or RETRACT) and reason (your brief reflection).'}, {'role':'user','content':user}]
        r=api.ask('revision_action',c,p);o=json_object(r['studentOutput']['raw'])
        action=o.get('action') if o and o.get('action') in ('KEEP','RETRACT') and not r['studentOutput']['tokenCapReached'] else None
        after=before;accepted=False;proposal=None
        if action:
            d={k:v for k,v in r.items() if k!='hash'};d['action']=action;after=H['apply_action'](before,H['sealed'](d))
        H['put_once'](folder/'01-action-note.json',after)
        # Preserve reflection as an uncertified text version, including wrong prose.
        after=H['attach_reflection'](after,r)
        if action=='RETRACT':
            p=[{'role':'system','content':'Simplify an expression: expand products over sums, combine constant coefficients and like terms, and represent repeated identical factors using powers. Preserve its value for every real input. Return ONE expression using * and **, without prose or an equality chain; if unsure write SKIP.'},
               {'role':'user','content':'You withdrew a previous notebook rule. Write your own replacement from the ORIGINAL expression: '+c['card']['left']+'. '+c['card']['variable']+' is real. No replacement formula is supplied.'}]
            proposal=api.ask('independent_editor',c,p);normalized=display_record(proposal)
            H['put_once'](folder/'normalized-proposal.json',normalized)
            audit=H['proposal_audit'](c,normalized);accepted=audit['accepted']
            after=H['attach_proposal'](after,normalized,audit)
            H['put_once'](folder/'replacement-audit.json',H['sealed'](audit))
        H['put_once'](folder/'02-new-note.json',after)
        after=H['check_seal'](H['read'](folder/'02-new-note.json'))
        follow=[];arms=[('no_note',before,True),('old_note',before,False),('new_note',after,False)]
        arms=arms[index%3:]+arms[:index%3]
        for variable,multiplier in [('q',1),('z',2)]:
            results={}
            for arm,memory,no_note in arms:
                task,p=follow_prompt(memory,variable,multiplier,no_note);answer=api.ask('follow_'+variable+'_'+arm,c,p)
                normalized=display_record(answer);H['put_once'](folder/('normalized-'+variable+'-'+arm+'.json'),normalized)
                results[arm]={'recordId':answer['recordId'],'raw':answer['studentOutput']['raw'],**strict_math(task,answer)}
            follow.append({'variable':variable,'multiplier':multiplier,'results':results})
        grounded=H['grounded'](c,props);truth=c['card']['knownExactIdentity']
        newcorrect=sum(x['results']['new_note']['strictCorrect'] for x in follow)
        helped=sum(not x['results']['old_note']['strictCorrect'] and x['results']['new_note']['strictCorrect'] for x in follow)
        harm=sum(x['results']['old_note']['strictCorrect'] and not x['results']['new_note']['strictCorrect'] for x in follow)
        row=H['sealed']({'caseId':c['id'],'cardId':c['card']['id'],'repeat':entry['repeat'],'trueOriginal':truth,
           'designedNote':c['card']['provenance']['kind']=='predeclared_designed_note','coldBelief':cold[c['card']['id']],
           'properties':props,'groundedConflict':grounded,'action':action,'reflectionRaw':r['studentOutput']['raw'],
           'replacementAccepted':accepted,'replacementRaw':None if proposal is None else proposal['studentOutput']['raw'],
           'oldHash':before['hash'],'newHash':after['hash'],'followup':follow,'newNoteStrictCorrect':newcorrect,
           'oldWrongToNewCorrect':helped,'oldCorrectToNewWrong':harm,'correctNoteWithdrawn':truth and action=='RETRACT',
           'candidateTwoFollowupClosedLoop':bool(not truth and grounded and action=='RETRACT' and accepted and newcorrect==2),
           'reflectionSemanticsRequireHumanReview':True,'initialMistakeAuthoredByAPIModel':False})
        H['put_once'](folder/'summary.json',row);rows.append(row)
        print('EPISODE '+json.dumps({k:row[k] for k in ('caseId','action','replacementAccepted','newNoteStrictCorrect','candidateTwoFollowupClosedLoop','correctNoteWithdrawn')},ensure_ascii=False),flush=True)
    false=[x for x in rows if not x['trueOriginal']];true=[x for x in rows if x['trueOriginal']]
    total={arm:sum(y['results'][arm]['strictCorrect'] for x in rows for y in x['followup']) for arm in ('no_note','old_note','new_note')}
    result=H['sealed']({'complete':True,'model':PLAN['model'],'weightsUpdated':0,'ruleUnits':5,'episodes':6,'falseRuleUnits':3,'falseEpisodes':4,'correctEpisodes':2,
      'groundedWrongEpisodes':sum(x['groundedConflict'] for x in false),'studentWithdrawalsWrongEpisodes':sum(x['action']=='RETRACT' for x in false),
      'verifiedReplacementWrongEpisodes':sum(x['replacementAccepted'] for x in false),'candidateTwoFollowupClosedLoops':sum(x['candidateTwoFollowupClosedLoop'] for x in false),
      'correctNoteWithdrawals':sum(x['correctNoteWithdrawn'] for x in true),'strictMathCounts':total,'strictMathDenominatorPerArm':12,
      'oldWrongToNewCorrect':sum(x['oldWrongToNewCorrect'] for x in rows),'oldCorrectToNewWrong':sum(x['oldCorrectToNewWrong'] for x in rows),
      'coldInvalidRecognitions':sum(bool(x['parsed'] and x['parsed'].get('validity')=='INVALID') for card,x in cold.items() if any(c['card']['id']==card and not c['card']['knownExactIdentity'] for c in PLAN['rules'])),
      'coldValidRecognitions':sum(bool(x['parsed'] and x['parsed'].get('validity')=='VALID') for card,x in cold.items() if any(c['card']['id']==card and c['card']['knownExactIdentity'] for c in PLAN['rules'])),
      'actualPOSTs':len(list((out/'attempts').glob('*.json'))),'savedResponses':len(list((out/'raw').glob('*.json'))),'rows':rows,
      'ownUnnoticedErrorRepairProven':False,'statisticalSignificanceClaimed':False,'spontaneousCounterexampleSearchClaimed':False})
    H['put_once'](out/'result.json',result)
    print(json.dumps({k:v for k,v in result.items() if k not in ('rows','hash')},ensure_ascii=False,indent=2),flush=True)
    print('OUTPUT '+str(out),flush=True)
    return result

if __name__=='__main__':
    if '--preflight' in sys.argv:
        assert len(PLAN['rules'])==5 and len(PLAN['episodes'])==6
        assert sum(not c['card']['knownExactIdentity'] for c in PLAN['rules'])==3
        assert normalize('v² * 435')=='v**2 * 435'
        assert json_object('{"action":"RETRACT"}')['action']=='RETRACT'
        assert json_object('KEEP or RETRACT') is None
        H['put_once'](WORK/'frozen-plan.json',H['sealed'](PLAN))
        print('PREFLIGHT OK; plan frozen; 65 planned maximum POSTs; real API calls=0')
    else:
        fd=sys.stdin.fileno();old=termios.tcgetattr(fd);new=list(old);new[3]&=~termios.ECHO
        termios.tcsetattr(fd,termios.TCSANOW,new);print('AUTH_INPUT_READY',flush=True)
        try:key=sys.stdin.readline().strip()
        finally:termios.tcsetattr(fd,termios.TCSANOW,old)
        try:
            frozen=H['check_seal'](H['read'](WORK/'frozen-plan.json'))
            assert {k:v for k,v in frozen.items() if k!='hash'}==PLAN
            run(key)
        except Exception as e:print('RUN_STOPPED '+(str(e) if type(e) is RuntimeError else type(e).__name__),flush=True);sys.exit(1)
        finally:key=None
