# Frozen Apertus memory-repair replication

2026-10-14. Model: swiss-ai/Apertus-v1.5-70B, temperature 0, max_tokens 1024. 63 real API POSTs completed; no parameter updates. Protocol, rule list, prompts, parsing and primary success criteria were frozen before generation. All raw responses, prompts and versioned notes are preserved.

## Results

| Outcome | Result |
|---|---:|
| Distinct rules / complete episodes | 5 / 6 |
| Wrong-rule units / wrong-rule episodes | 3 / 4 |
| Actual wrong-note withdrawals | 4 / 4 |
| Model-written equivalent simplified replacements | 4 / 4 |
| Predeclared strict two-follow-up closed loops | 3 / 4 |
| Mistaken withdrawals of correct rules | 0 / 2 |
| Correct-rule actions | 1 JSON KEEP; 1 explicit KEEP with prose (invalid JSON interface) |
| Content-correct no-note / old-note / revised-note responses | 12/12 / 10/12 / 12/12 |
| Strict collected no-note / old-note / revised-note responses | 10/12 / 10/12 / 12/12 |

The two no-note strict failures were mathematically equivalent factored expressions, not wrong answers: `18 * (z + 2/3)` is equivalent to `18*z + 12` but did not meet the explicitly requested expanded/collected form. The old-note content failures were both `2 * 435^2 * z^2` instead of the original product's coefficient. They occurred in two repetitions of the same underlying real-435 task. The new-note condition removed these two observed bad-memory errors, but did not exceed the no-note baseline in mathematical content accuracy.

One distributed-rule episode failed the primary sign-choice interface because the model wrote a correct step-by-step explanation rather than a single categorical token. It evaluated the left side at -2/9 as 4 (POSITIVE) and the right as 0 (ZERO), then selected RETRACT and generated the verified replacement `9*v + 6`; both revised-note follow-ups passed. The predeclared metric remains 3/4. A separate, explicitly post-hoc semantic annotation records the correctly written signs without repairing or replacing raw outputs.

The second correct-rule episode returned `KEEP` plus a careful explanation instead of JSON. The strict action parser rejected the format, and the host left the rule unmodified. Both the model's actual written action and the system's no-edit behavior are reported; this is not counted as a compliant JSON KEEP. The same original response correctly warns that agreement at one input does not prove universal equality.

## Experimental units and controls

- Genuine old 0.5B wrong ZIP: `435 * v * v = 435^2`, with v=0 as the fixed witness. This source was already explored in the earlier 72-call diagnostic and is a replication, not a blind held-out rule.
- Designed wrong square ZIP: `4 * v * v = 4**2`, with v=0.
- Designed wrong distribution ZIP: `3 * (3 * v + 2) = 9 * v + 2`, with v=-2/9.
- Genuine correct old ZIP: `1 * (315 * v) = 315 * v`, with v=0.
- Designed correct distribution ZIP: `3 * (3 * v + 2) = 9 * v + 6`, with v=-2/9.
- The real-435 episode is repeated once. This gives 6 episodes, not 6 independent rules. Each has q and z follow-ups, with the second multiplying the original expression by 2.

The actor separately computes each sign without being shown the saved rule. It then sees its own actual check text and decides KEEP/RETRACT. After an actual withdrawal, the actor independently simplifies the original expression. An exact rational polynomial auditor checks its untouched expression (with superscript digits normalized only as display notation). Only a verified model-written replacement is admitted. The note is saved and read back before retrieval. No expected sign, FAIL label, correctness score, or replacement formula is sent to the actor. Control notes naturally contain their own candidate expressions; the editor prompt does not supply a target formula.

The three math conditions use the same instructions, target expressions, token budget and temperature. Their order cycles across episodes. Only retrieved memory differs. No ordinary-retry/editor-only comparison with equal full inference budget was performed; improved output relative to poisoned memory cannot be attributed uniquely to reflection training. API serving revisions were not tensor-hash pinned; returned model IDs and fingerprints are recorded.

## What this supports

In this limited polynomial setting, a frozen LLM-based system can compute a designed counterexample, withdraw an inherited erroneous note, write and persist a checked replacement, and reuse it in later requests. The strictly compliant workflow repeated on the genuine old note and on a designed square variant. The distributed-rule evidence is mathematically correct but has a formatting failure under the frozen primary interface.

This is a promising systems mechanism for protecting external memory from persistent errors. It is not a new pretrained GPT, proof of broad intrinsic self-correction, evidence of a new mathematical capability, or proof that the API model repaired an error it originally authored. Cold assessments already identified two wrong notes as INVALID; the third assessment's label said VALID while its reason explicitly described the invalidity. Therefore the apparent label mistake is not enough to call the underlying error unnoticed.

## Plausible research directions, not established claims

1. **Checkable, retractable memory.** Store scope, provenance, counterexamples, versioned rules and exact certificates where available. Measure both repairing wrong notes and preserving correct notes, including how formats and parsers affect behavior. Our observed two poisoned-memory errors are a concrete motivation.
2. **Outcome-driven memory learning.** Reward later task performance and penalize correct-to-wrong edits, rather than reward fluent reflections or raw withdrawal counts. Existing Memory-R1 trains structured memory operations with outcome-based RL; our different contribution would need to be demonstrated through exact-rule admission, robust boundaries and reproducible ablations.
3. **Learn when to check or use a note under a budget.** Compare a small learned controller plus reliable checks with fixed always-check, always-keep and always-rewrite policies using equal token/call budgets. SCoRe's discussion of correction-policy collapse motivates careful objectives, but this inference-only run does not test RL or demonstrate its effects.
4. **Transfer to genuinely new definitions and changing tasks.** A strong model already knows the algebra in this pilot. Unknown user-defined functions, new game rules, executable tools or evolving facts are better future settings for testing information the base model does not already possess. This is a proposed experiment, not a result achieved here.

Related work confirms that reflection and memory management are established research directions; it does not establish global novelty for this project. The immediate contribution is the engineering/evaluation of provenance-preserving, formally checked memory repair and its failure modes under limited resources.

## Primary references

- Shinn et al., *Reflexion: Language Agents with Verbal Reinforcement Learning* (2023): reflective text in episodic memory without weight updates. https://arxiv.org/abs/2303.11366
- Madaan et al., *Self-Refine* (2023): iterative generation, feedback and refinement using one model. https://arxiv.org/abs/2303.17651
- Huang et al., *Large Language Models Cannot Self-Correct Reasoning Yet* (ICLR 2024): intrinsic reasoning correction can be ineffective without reliable feedback. This is a scoped empirical finding, not an impossibility theorem. https://arxiv.org/abs/2310.01798
- Kumar et al., *Training Language Models to Self-Correct via Reinforcement Learning* (SCoRe, 2024): multi-turn RL, distribution issues and correction behavior collapse. https://arxiv.org/abs/2409.12917
- Yan et al., *Memory-R1* (updated January 2026): learned ADD/UPDATE/DELETE/NOOP and memory use with outcome-based RL. https://arxiv.org/abs/2508.19828
- Guo et al., *MemFactory* (2026): modular infrastructure for training and evaluating memory-augmented agents. https://arxiv.org/abs/2603.29493

No API key, authorization header or weights are included. All archived raw responses are real API outputs, not mock fixtures. Offline preflight was distinct from real generation. No significance, competition-rank or general intelligence claim is made.
