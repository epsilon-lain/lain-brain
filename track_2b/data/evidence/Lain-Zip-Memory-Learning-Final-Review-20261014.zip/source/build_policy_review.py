"""Audit exploratory records and package both completed experiments."""
import hashlib,json,re,runpy,zipfile
from pathlib import Path
ROOT=Path(__file__).parent
L=runpy.run_path(str(ROOT/'learn_memory_policy.py'),run_name='bundle_policy');H=L['H']
PRIMARY=L['WORK']/'zip-policy-5411d33ddbc5';EXTRA=L['WORK']/'feedback-note-pilot'
R=H['check_seal'](H['read'](PRIMARY/'result.json'));E=H['check_seal'](H['read'](EXTRA/'result.json'))
raw={r['recordId']:r for p in (EXTRA/'raw').glob('*.json') for r in [H['check_seal'](H['read'](p))]}
counts={'correct':0,'wrongInteger':0,'skip':0,'format':0}
for row in E['rows']:
 c=next(c for c in L['PLAN']['cases'] if c['id']==row['caseId'])
 state=H['check_seal'](H['read'](EXTRA/'memory'/(row['caseId']+'.json')))
 assert state['hash']==row['memoryHash'] and state['activeNotes']==[row['newNoteRaw']]
 assert state['activeNotes'][0]==raw[state['noteRecordId']]['studentOutput']['raw']
 for ans in row['answers']:
  rr=raw[ans['recordId']];gold=c['currentHiddenCoefficients'][0]*ans['input']+c['currentHiddenCoefficients'][1]
  assert rr['studentOutput']['raw']==ans['raw'] and gold==ans['expectedValueAuditOnly']
  score=L['score_value'](ans['raw'],gold,rr['studentOutput']['tokenCapReached']);assert score==ans['score']
  base=H['check_seal'](H['read'](PRIMARY/'raw'/(ans['primaryFormulaBaseline']['recordId'][4:]+'.json')))
  assert rr['request']['messages'][0]==base['request']['messages'][0]
  # Exactly equal query and trailing instruction; only active memory differs.
  for m in (rr,base):assert m['request']['messages'][1]['content'].splitlines()[0]=='Query the CURRENT opaque affine function '+c['functionName']+' at x='+str(ans['input'])+'.'
  suffix='\nUse the available working notes if they determine a value. If they do not, return SKIP. No function observations or hidden coefficients are supplied here.'
  assert all(m['request']['messages'][1]['content'].endswith(suffix) for m in (rr,base))
  counts['correct']+=int(score['correct']);counts['wrongInteger']+=int(score['kind']=='integer' and not score['correct']);counts['skip']+=int(score['kind']=='skip');counts['format']+=int(score['kind']=='format')
assert E['flexibleNoteCorrect']==counts['correct']==0
attempts=sum(len(list((p/'attempts').glob('*.json'))) for p in (PRIMARY,EXTRA));assert attempts==112
assert len(raw)==10 and all(H['read'](p)['status']=='committed' for p in (EXTRA/'attempts').glob('*.json'))
analysis=H['sealed']({'complete':True,'allExploratoryAnswerScoresAndNoteProvenanceChecked':True,
 'combinedAttemptedPOSTs':attempts,'combinedCommittedResponses':110,'exploratoryBreakdown':counts,
 'primaryScoresUnchanged':True,'experiment1ControllerUpdates':128,'experiment2ParameterUpdates':0,
 'humanUnknownLearningMethodDiscoveryClaimed':False,'statisticalSignificanceClaimed':False})
H['atomic_json'](EXTRA/'analysis.json',analysis)
report='''# Lain ZIP：后续收益驱动的记忆学习审阅包

本轮真实运行已完成。共110条已保存的CSCS API响应，112次请求尝试（含中断造成的2次不确定请求），模型为swiss-ai/Apertus-v1.5-70B。没有更新API语言模型权重。

## 核心结论

1. 独立记忆控制器发生了128次真实参数更新，逐步重放核验了梯度、随机采样、Adam状态、权重哈希与奖励来源。新题平均效用从未训练均匀策略的−0.56975提高到贪心策略的−0.12。
2. 这种提高来自撤回后弃答：4组新题全部RETRACT，8问全部SKIP，正确0/8。结果与“始终撤回”相同，并没有超过固定策略，不能证明有条件的记忆修订或解题学习。
3. 实际生成的6个TRAIN情形，按预定效用最优动作全部是撤回；所有新公式都没有满足当前观察。题库预设了稳定/变化/信息不足，却没有产生奖励保留与覆盖的有效行为样本。这是本轮训练分布的缺陷，不是反思能力普遍不存在的证明。
4. 额外10次调用测试“真实TRAIN失败反馈→模型提出笔记方法→3组TEST改写笔记→6次后续读取”。自由笔记条件正确0/6，原公式笔记条件1/6。自由笔记产生2次错误整数、4次弃答；没有带来正确率提升。

## 分层发现

模型提出保留原始观察、写出推导、标明不确定性的方法。但它的方法同时包含错误认识：在已经知道函数是仿射函数的条件下，仍认为两个不同输入的观察不足以唯一确定函数。两个不同输入的观察可以唯一确定仿射函数；一个观察不可以。

一张自由笔记正确推出F(x)=5x−3，却也错误地对已知仿射函数的外推保留非线性疑虑。后续回答x=2为10、x=4为23，正确应为7、17。另一张笔记推出3x+8，但夹杂“两点不足”的错误解释，两个后续问题都返回SKIP。原文完整保留，不能把写出正确公式当作可靠复用已经成立。

因此，目前证据支持“控制器能跟随后续收益改变策略”，不支持“有撤回能力就会自动获得有效自我学习”。这次策略实际退化为固定撤回；反馈产生的笔记方法也未可靠改善任务。奖励目标、训练分布、笔记内容与读取执行需要分别验收。

## 设计边界

主实验是外部线性softmax控制器在真实API任务结果上的离线REINFORCE/Adam训练。8个特征由人设计，包含程序计算的笔记与观察一致性；这不是语言模型自己学出的矛盾检查。KEEP/OVERWRITE/APPEND/RETRACT和奖励也由人定义。零奖励对照是零更新参考，并非独立API训练组。

TEST没有参与梯度；最终权重冻结后，选择只读取公开观察与笔记特征。选择结果引用每个真实反事实动作试验的缓存回答，并非另一次实时策略执行。这些边界均保留在协议和报告中。

补充实验是看到TRAIN失败后设计的探索性尝试，设计时主实验TEST正在运行；它只向模型显示TRAIN反馈，不显示任何TEST评分或正确公式。保存观察与推导的方向也受到人类提示，不能宣称发现了人类未知的学习方式。额外推理调用与笔记长度没有与原单公式笔记匹配，不能进行严格因果归因。更长笔记没有获益。

评分保留冻结标准：只接收单个整数或SKIP。弃答不等于正确解答；信息不足情形的弃答是合理的不确定性行为，仍与数值答对分别报告。主效用对错误整数与格式不合规的惩罚不同，也有被利用的风险。报告另存显式最终答案的次级审阅，未改写原奖励。

## 两处实现修正

主实验在任何梯度或TEST生成前修复了3x这类隐式乘法的显示解析，复用43条原文。补充实验在8条原文后修复了原笔记SKIP导致空记忆文本替换断言的问题，只补剩余两问。修正前源码和收据均入包，评分与题目不变。

## 下轮实验具体条件

在投入梯度前检查实际TRAIN结果是否真的包含收益支持的“保留正确笔记”“覆盖错误笔记”“证据不足时撤回”。如果语言模型从未生成可用笔记，不应把只会撤回的训练当作修订学习的有效测试。

给笔记写作器与管理器分别定义真实后续任务收益；与无笔记、旧笔记、初始策略、固定动作及同预算普通重写比较。检查收益来自正确率还是弃答；同时验收观察事实正确性、规则适用条件、公式正确性和后续读取。用未见函数、多随机种子和独立重复检验泛化。至此才有资格评估“有条件的自我学习”是否稳定成立。

没有统计显著性、普遍鲁棒性、全新学习方法或竞赛排名的声明。

## 文件

- primary/：主实验的全部协议、原文、动作记忆、128步权重与优化器、独立审计及源码。
- exploratory/：反馈笔记试验的全部协议、10条原文、笔记、评分及实现修正记录。
- source/：本轮可重跑脚本与审阅包构建脚本。凭据通过不回显stdin输入，不存入文件。
- manifest.json：各文件SHA256；ZIP的CRC与所有哈希均已核验。
'''
files={'README-zh.md':report.encode(),'summary.json':json.dumps(analysis,ensure_ascii=False,indent=2).encode()}
with zipfile.ZipFile(ROOT/'Lain-Zip-Outcome-Memory-Policy-Review-20261014.zip') as z:
 for name in z.namelist():files['primary/'+name]=z.read(name)
for p in EXTRA.rglob('*'):
 if p.is_file():files['exploratory/'+str(p.relative_to(EXTRA))]=p.read_bytes()
for name in ('try_feedback_note.py','build_policy_review.py'):files['source/'+name]=(ROOT/name).read_bytes()
for data in files.values():assert re.search(rb'\bsk-[A-Za-z0-9_-]{24,}\b',data) is None
manifest={name:hashlib.sha256(data).hexdigest() for name,data in files.items()};files['manifest.json']=json.dumps(manifest,indent=2).encode()
archive=ROOT/'Lain-Zip-Memory-Learning-Final-Review-20261014.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for name,data in files.items():z.writestr(name,data)
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 for name,h in manifest.items():assert hashlib.sha256(z.read(name)).hexdigest()==h
print(json.dumps({'zip':str(archive),'bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'checkedFileCount':len(manifest),'summary':analysis},ensure_ascii=False,indent=2))
