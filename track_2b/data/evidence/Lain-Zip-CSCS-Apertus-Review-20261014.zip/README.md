# CSCS Apertus API: real note-revision diagnostic, 2026-10-14

72 actual authenticated chat-completion requests completed; 72 untouched raw responses saved. No training updates or local student-weight loading occurred. Requested and returned models were Apertus v1.5 8B and 70B. All earlier failures are included, not replaced by the exploratory success.

## Observed results

The predeclared five-episode 8B test correctly computed the decisive zero/positive checks for both wrong rules, but withdrew neither rule. All three evidence controls returned KEEP. The separate 70B replay withdrew the real 435 wrong note but initially supplied an invalid replacement. Structured factor outputs also had format failures; these are interface failures rather than evidence of missing mathematical knowledge.

Exploratory natural-note review (with temperature 0 and the model's own previously recorded checks) made both models choose RETRACT, but both left the replacement field null. Separate prompts saying “collect” produced unchanged products, which were rightly rejected as a newly collected rule. Specifying the operation “represent repeated identical factors using powers” made 70B write `v² * 435`. The original ASCII-only auditor rejected this correct mathematical notation. A narrowly scoped display conversion (`²` to `**2`) admitted precisely the model's own expression; it inserted no missing factor or answer.

## One minimal inherited-memory repair instance

1. Genuine old 0.5B ZIP: `435 * v * v = 435^2`, claimed for every real v.
2. 70B independently classified the original left side at v=0 as ZERO and the saved right side at the same v=0 as POSITIVE.
3. Its natural-review JSON action was RETRACT, with a correct short reason citing that contradiction.
4. Its own subsequent power-rewrite output was `v² * 435`; exact rational polynomial checking confirms equivalence to the original product.
5. A new formal note was committed to disk and read back. Its expression `v**2 * 435` is a notation conversion of the raw model expression, not a teacher-provided replacement.
6. On a newly bound variable q, given the reloaded note, it wrote `435 * q * q = q² * 435`. Both the equality and collected final expression pass the display-normalized polynomial audit.

This is an exploratory, assisted, one-follow-up existence instance of repairing inherited erroneous memory and reusing the repaired rule. It is not the originally predeclared two-follow-up success criterion. The error was authored by the earlier 0.5B student, not by 70B itself. The API 8B cold answer before seeing the note was already correct. No broad spontaneous self-correction, own-unnoticed-error repair, training gain, isolated causal memory benefit, or statistical significance is established. Prompts and sampling changed during the exploratory diagnostics; all changes and parent evidence IDs are recorded.

The natural language drafts are not automatically certified. In particular, the separate 8B natural-review draft incorrectly asserted validity only at v=435; the successful 70B parent reason contains no such assertion. An earlier structured 70B reflection also miscomputed the numeric square. These raw errors remain available for review.

## Contents

- `summary.json`: compact audit-backed results and limitations.
- `results/`: all prompt bodies, actual outputs, API model IDs/usage, attempt receipts, case summaries, memory versions, and mathematical audits.
- `source/`: the exact standalone API runtime and exploratory runner source. Secrets are supplied through non-echoing terminal input, not embedded in these files.
- `manifest.json`: SHA-256 hashes of all enclosed evidence and source files.

No API key, authorization header, model weights, or secret transcript is included.
