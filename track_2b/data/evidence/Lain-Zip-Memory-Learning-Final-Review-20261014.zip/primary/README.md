# Outcome-trained memory-operation pilot (v27)

## Verified result

Model: swiss-ai/Apertus-v1.5-70B. Six TRAIN environments, four held-out environments, eight held-out questions. An external linear softmax controller received 128 real NumPy Adam/REINFORCE parameter-changing updates. The API LLM received **zero** weight updates. All 128 updates were independently replayed from their original rewards, RNG samples, optimizer states and hashes.

Frozen greedy actions on TEST: ['RETRACT', 'RETRACT', 'RETRACT', 'RETRACT'].
Greedy mean utility: -0.120000; learned stochastic expected utility: -0.122417; initial uniform policy expected utility: -0.569750.
Constant-operation utilities: {"KEEP": -0.9125, "OVERWRITE": -0.6295000000000001, "APPEND": -0.617, "RETRACT": -0.12000000000000001}. Best constant action in this small TEST table: RETRACT (descriptive, selected after evaluation).

| Policy | Correct | Wrong integer | SKIP | Format failure |
|---|---:|---:|---:|---:|
| KEEP | 0/8 | 7 | 0 | 1 |
| OVERWRITE | 1/8 | 5 | 2 | 0 |
| APPEND | 0/8 | 3 | 4 | 1 |
| RETRACT | 0/8 | 0 | 8 | 0 |
| LEARNED | 0/8 | 0 | 8 | 0 |

Utility is not accuracy. Correct=+1, wrong integer=-1, SKIP=-0.10, invalid format=-0.25, plus frozen operation and memory-character costs. Abstaining can beat confidently wrong notes. Invalid prose is penalized less than a wrong integer, a limitation of this objective; a secondary explicit-final-answer audit is retained separately, without changing rewards or primary results.

## What was actually trained

Opaque named functions are affine, with coefficients known only to the evaluator. The LLM writes its old note from old observations and a candidate new note from recent observations; observations may be stable, changed, or insufficient. Later solving sees saved notes only, without observations or gold coefficients. All four operations (KEEP/OVERWRITE/APPEND/RETRACT) are physically saved, read back and tested by real API queries.

The controller's eight **human-designed** features include host-computed affine parsing and agreement of notes with public observations. Thus conflict checking here is supplied by a program, not learned intrinsic mathematical introspection. Actions and reward are human-designed too. The controller samples one action and trains from its real, cached subsequent-answer utility; this is offline contextual-bandit replay, not fresh LLM rollouts on every gradient. The zero-reward reference stays exactly at zero parameters with zero optimizer steps; it is not a separately sampled actor training run.

All TRAIN outcomes precede the final controller; TEST does not enter updates. For evaluation, all TEST counterfactual operations are queried, then the frozen controller selects using only its public features. Selected results refer to the real cached trials for that exact bank, not an additional live chosen-policy rollout. Small sample, one seed, one serving model, no statistical significance claim.

## Interpretation boundaries

An increase relative to a uniform untrained policy establishes only a limited outcome-driven controller effect under this reward and these features. To establish useful conditional memory management, it must also compete with constant policies and preserve correct notes. To establish better mathematical learning, it must increase correct answers; higher utility through SKIP alone is insufficient. If RETRACT wins everywhere, this is policy collapse toward abstention, not successful conditional repair.

This experiment does not train the LLM's note-writing weights. It cannot establish that the LLM independently learns how to write better notes or discovers a learning method unknown to humans. It explicitly tests whether a small external policy can learn useful operations from subsequent consequences. The original 435 example and the earlier frozen repair replication are different experiments; their positive outcomes cannot be substituted for this test.

## Reproducibility and correction

Frozen protocol, all raw model prompts/responses, memory versions, receipts, parameters and optimizer moments are included. 100 committed raw API responses, 102 attempted POSTs, 2 uncertain pending attempts from interrupted sessions. No automatic retries. Logging inherited a /72 denominator from the older transport; this experiment's actual frozen cap is 112, with 100 planned calls.

Before any controller commits or TEST responses, the implementation was corrected to use the existing display normalizer for implicit multiplication such as `3x`. The 43 existing raw responses were copied unchanged; no formula or answer was replaced. Original source and correction receipt are included. Primary cases/rewards/prompts were unchanged. Original pre-correction data remain archived separately.

No credentials, authorization headers, pretrained weights, or claims of novelty, broad robustness, statistical significance or competition ranking are included.
