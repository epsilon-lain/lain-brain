import sys,termios,runpy,json
from pathlib import Path
fd=sys.stdin.fileno();old=termios.tcgetattr(fd);new=list(old);new[3]&=~termios.ECHO
termios.tcsetattr(fd,termios.TCSANOW,new);print('AUTH_INPUT_READY',flush=True)
try:key=sys.stdin.readline().strip()
finally:termios.tcsetattr(fd,termios.TCSANOW,old)
m=runpy.run_path(str(Path(__file__).with_name('Lain-Zip-Apertus-API-Test.py')),run_name='zip_api_runtime')
# A separate, explicitly limited 70B replication of the real inherited 435
# episode. The 8B run remains intact and is reported regardless of outcome.
work=Path(__file__).parent/'results';h=m['setup'](work)
cfg={'key':key,'url':'https://api.inference.cscs.ch/v1','model':'swiss-ai/Apertus-v1.5-70B','token_field':'max_tokens','budget':1024,'extra':{}}
out=work/'zip-apertus-70b-targeted-435';out.mkdir(exist_ok=True)
h['put_once'](out/'protocol.json',h['sealed']({'model':cfg['model'],'task':'independent replication of source435 inherited-note episode','sourcePlanHash':m['PLAN']['priorPlanHash'],'selectedAfter8BFirstCaseObserved':True,'allModelResultsMustBeReported':True,'caseCount':1,'maxRequestsThisArm':14,'trainingUpdates':0,'claimedOwnErrorRepair':False}))
api=m['API'](cfg,out,h);original_ask=api.ask
def ask(*args,**kwargs):
    total=len(list(work.glob('*/attempts/*.json')))
    if total>=72:raise RuntimeError('Combined 8B/70B 72-attempt cap reached')
    return original_ask(*args,**kwargs)
api.ask=ask
try:
    row=m['episode'](api,m['PLAN']['cases'][0],h)
    h['put_once'](out/'result.json',h['sealed']({'complete':True,'requestedModel':cfg['model'],'row':row,'trainingUpdates':0,'calls':len(list((out/'attempts').glob('*.json'))),'caseSelectionExploratory':True}))
    print(json.dumps(row,ensure_ascii=False,indent=2),flush=True)
except Exception as e:
    print('RUN_STOPPED '+(str(e) if type(e) is RuntimeError else type(e).__name__),flush=True)
finally:
    key=None;cfg['key']=None
    print('REVIEW_ZIP '+str(m['package'](out)),flush=True)
