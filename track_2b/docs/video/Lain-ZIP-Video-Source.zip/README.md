# Video authoring inputs

Actual recorded-evidence UI captures, original evidence cards, Microsoft Jenny Neural synthetic English narration (-8% rate), and sentence boundary timestamps. No live inference is depicted.

Install Pillow and ffmpeg with libass. Run:

python build_neural_video.py --assets assets --out rendered

The source captions and screenshots contain only public experiment data.
